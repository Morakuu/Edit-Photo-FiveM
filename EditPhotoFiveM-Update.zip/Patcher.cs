using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.IO.Compression;
using System.Net;
using System.Threading;
using System.Windows.Forms;

namespace FiveMPhotoEditorPatcher
{
    public class PatcherForm : Form
    {
        private Label lblStatus;
        private Label lblFooter;
        private Label lblTitle;
        private Label lblSubTitle;
        private int currentProgress = 0;
        private string changelogText = "[Nowości w Aktualizacji]:\n\nWczytywanie listy zmian z GitHuba...";

        public PatcherForm()
        {
            this.FormBorderStyle = FormBorderStyle.None;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Size = new Size(800, 460);
            this.BackColor = Color.FromArgb(10, 10, 11);
            this.TopMost = true;
            this.DoubleBuffered = true;

            lblTitle = new Label();
            lblTitle.Text = "EDIT PHOTO FIVEM";
            lblTitle.Font = new Font("Segoe UI", 20f, FontStyle.Bold);
            lblTitle.ForeColor = Color.White;
            lblTitle.Location = new Point(35, 25);
            lblTitle.AutoSize = true;
            this.Controls.Add(lblTitle);

            lblSubTitle = new Label();
            lblSubTitle.Text = "SYSTEM AUTOMATYCZNEGO PATCHOWANIA GITHUB";
            lblSubTitle.Font = new Font("Segoe UI", 9f, FontStyle.Bold);
            lblSubTitle.ForeColor = Color.FromArgb(70, 190, 255);
            lblSubTitle.Location = new Point(37, 62);
            lblSubTitle.AutoSize = true;
            this.Controls.Add(lblSubTitle);

            lblStatus = new Label();
            lblStatus.Text = "Łączenie z serwerem aktualizacji GitHub...";
            lblStatus.Font = new Font("Segoe UI", 9.5f, FontStyle.Regular);
            lblStatus.ForeColor = Color.FromArgb(161, 161, 170);
            lblStatus.BackColor = Color.Transparent;
            lblStatus.Location = new Point(50, 285);
            lblStatus.Size = new Size(440, 25);
            lblStatus.TextAlign = ContentAlignment.MiddleCenter;
            this.Controls.Add(lblStatus);

            lblFooter = new Label();
            lblFooter.Text = "Patcher v2.0.0 • Created by Suslowatyy";
            lblFooter.Font = new Font("Segoe UI", 8.5f, FontStyle.Regular);
            lblFooter.ForeColor = Color.FromArgb(100, 116, 139);
            lblFooter.BackColor = Color.Transparent;
            lblFooter.Location = new Point(20, 425);
            lblFooter.AutoSize = true;
            this.Controls.Add(lblFooter);
        }

        public void SetChangelog(string cl)
        {
            if (this.InvokeRequired) { this.Invoke(new Action(() => SetChangelog(cl))); return; }
            changelogText = "[Nowości w Aktualizacji]:\n\n" + cl.Replace("|", "\n");
            this.Invalidate();
        }

        public void UpdateStatus(string text, int progress = -1)
        {
            if (this.InvokeRequired)
            {
                this.Invoke(new Action(() => UpdateStatus(text, progress)));
                return;
            }
            lblStatus.Text = text;
            if (progress >= 0) currentProgress = Math.Min(100, Math.Max(0, progress));
            else currentProgress = (currentProgress + 3) % 100;

            this.Invalidate();
            Application.DoEvents();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            // Downloading Section Header
            using (Font fSection = new Font("Segoe UI", 13, FontStyle.Bold))
            using (SolidBrush bWhite = new SolidBrush(Color.FromArgb(244, 244, 245)))
            {
                StringFormat sf = new StringFormat() { Alignment = StringAlignment.Center };
                g.DrawString("Pobieranie i Instalowanie Patcha GitHub", fSection, bWhite, new PointF(270, 130), sf);
            }

            // Progress Bar Track
            Rectangle trackRect = new Rectangle(50, 315, 440, 18);
            using (GraphicsPath trackPath = GetRoundedRectPath(trackRect, 9))
            using (SolidBrush trackBrush = new SolidBrush(Color.FromArgb(18, 18, 22)))
            using (Pen trackPen = new Pen(Color.FromArgb(40, 40, 50), 1))
            {
                g.FillPath(trackBrush, trackPath);
                g.DrawPath(trackPen, trackPath);
            }

            // Progress Bar Fill
            if (currentProgress > 0)
            {
                int fillWidth = (int)(440f * (currentProgress / 100f));
                if (fillWidth < 18) fillWidth = 18;
                Rectangle fillRect = new Rectangle(50, 315, fillWidth, 18);
                using (GraphicsPath fillPath = GetRoundedRectPath(fillRect, 9))
                using (LinearGradientBrush lgb = new LinearGradientBrush(fillRect, Color.FromArgb(24, 150, 220), Color.FromArgb(70, 190, 255), 0f))
                {
                    g.FillPath(lgb, fillPath);
                }
            }

            // Version Badge
            Rectangle badgeRect = new Rectangle(240, 345, 60, 22);
            using (GraphicsPath badgePath = GetRoundedRectPath(badgeRect, 11))
            using (SolidBrush badgeB = new SolidBrush(Color.FromArgb(18, 18, 22)))
            using (Pen badgeP = new Pen(Color.FromArgb(70, 190, 255), 1))
            using (Font fBadge = new Font("Segoe UI", 8.5f, FontStyle.Bold))
            using (SolidBrush bWhite = new SolidBrush(Color.White))
            {
                g.FillPath(badgeB, badgePath);
                g.DrawPath(badgeP, badgePath);
                StringFormat sf = new StringFormat() { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center };
                g.DrawString("v2.0.0", fBadge, bWhite, badgeRect, sf);
            }

            // Right Changelog Panel
            Rectangle rightPanel = new Rectangle(520, 110, 250, 290);
            using (GraphicsPath rightPath = GetRoundedRectPath(rightPanel, 12))
            using (SolidBrush pBrush = new SolidBrush(Color.FromArgb(18, 18, 22)))
            using (Pen pPen = new Pen(Color.FromArgb(40, 40, 50), 1))
            {
                g.FillPath(pBrush, rightPath);
                g.DrawPath(pPen, rightPath);
            }

            // Changelog text
            using (Font fChange = new Font("Segoe UI", 8.5f, FontStyle.Regular))
            using (SolidBrush bText = new SolidBrush(Color.FromArgb(200, 200, 200)))
            {
                RectangleF textRect = new RectangleF(535, 125, 220, 260);
                g.DrawString(changelogText, fChange, bText, textRect);
            }

            // Bottom Sky-Blue Glow Line
            using (LinearGradientBrush glowLine = new LinearGradientBrush(new Rectangle(0, 457, 800, 3), Color.Transparent, Color.FromArgb(70, 190, 255), 0f))
            {
                g.FillRectangle(glowLine, 0, 457, 800, 3);
            }

            // Outer Border
            g.DrawRectangle(new Pen(Color.FromArgb(40, 40, 50), 1), 0, 0, this.Width - 1, this.Height - 1);
        }

        private GraphicsPath GetRoundedRectPath(Rectangle bounds, int radius)
        {
            GraphicsPath path = new GraphicsPath();
            int d = radius * 2;
            path.AddArc(bounds.X, bounds.Y, d, d, 180, 90);
            path.AddArc(bounds.Right - d, bounds.Y, d, d, 270, 90);
            path.AddArc(bounds.Right - d, bounds.Bottom - d, d, d, 0, 90);
            path.AddArc(bounds.X, bounds.Bottom - d, d, d, 90, 90);
            path.CloseFigure();
            return path;
        }
    }

    class Program
    {
        private const string GITHUB_VERSION_URL = "https://raw.githubusercontent.com/Morakuu/Edit-Photo-FiveM/main/version.json";

        [STAThread]
        static void Main(string[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            PatcherForm splash = new PatcherForm();
            splash.Show();
            Application.DoEvents();

            string appFolder = AppDomain.CurrentDomain.BaseDirectory;
            string currentVer = GetInstalledVersion(appFolder);

            try
            {
                ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072 | (SecurityProtocolType)768 | SecurityProtocolType.Tls;

                splash.UpdateStatus("Sprawdzanie dostępności najnowszych aktualizacji GitHub...", 20);
                Thread.Sleep(500);

                // Kill running app engine before patching
                KillProcess("EditPhotoEngine");

                string latestVer = currentVer;
                string downloadUrl = "";
                string changelog = "";

                using (WebClient wc = new WebClient())
                {
                    wc.Headers.Add("User-Agent", "EditPhotoFiveM-Patcher/2.0");
                    wc.Headers.Add("Cache-Control", "no-cache");

                    try {
                        string json = wc.DownloadString(GITHUB_VERSION_URL + "?t=" + DateTime.Now.Ticks);
                        latestVer = ExtractJsonValue(json, "latestVersion") ?? currentVer;
                        downloadUrl = ExtractJsonValue(json, "downloadUrl") ?? "";
                        changelog = ExtractJsonValue(json, "changelog") ?? "Brak opisu zmian.";
                    }
                    catch { }

                    if (!string.IsNullOrEmpty(changelog)) splash.SetChangelog(changelog);

                    if (!string.IsNullOrEmpty(downloadUrl) && latestVer != currentVer)
                    {
                        splash.UpdateStatus("Pobieranie paczki aktualizacyjnej v" + latestVer + " z GitHuba...", 45);

                        string tempZip = Path.Combine(Path.GetTempPath(), "EditPhotoFiveM-Update.zip");
                        if (File.Exists(tempZip)) try { File.Delete(tempZip); } catch { }

                        try {
                            using (WebClient dlClient = new WebClient()) {
                                dlClient.Headers.Add("User-Agent", "EditPhotoFiveM-Patcher/2.0");
                                dlClient.DownloadFile(new Uri(downloadUrl), tempZip);
                            }
                        } catch (Exception ex) {
                            splash.UpdateStatus("Błąd pobierania z GitHuba: " + ex.Message, 50);
                            Thread.Sleep(1000);
                        }

                        if (File.Exists(tempZip) && new FileInfo(tempZip).Length > 100)
                        {
                            splash.UpdateStatus("Rozpakowywanie i nadpisywanie plików (v" + latestVer + ")...", 90);
                            ExtractAndOverwrite(tempZip, appFolder);

                            // Save new version to local version.json
                            try {
                                string newVerJson = "{\n  \"latestVersion\": \"" + latestVer + "\",\n  \"hasUpdate\": false,\n  \"downloadUrl\": \"\",\n  \"changelog\": \"" + changelog.Replace("\"", "\\\"").Replace("\n", "\\n") + "\"\n}";
                                File.WriteAllText(Path.Combine(appFolder, "version.json"), newVerJson);
                            } catch { }

                            try { File.Delete(tempZip); } catch { }
                        }

                        splash.UpdateStatus("Aktualizacja v" + latestVer + " zainstalowana! Uruchamianie edytora...", 100);
                        Thread.Sleep(600);
                    }
                    else
                    {
                        splash.UpdateStatus("Sprawdzono aktualizacje. Baza plików jest aktualna (v" + currentVer + ").", 100);
                        Thread.Sleep(500);
                    }
                }
            }
            catch
            {
                splash.UpdateStatus("Uruchamianie silnika Edit Photo FiveM...", 100);
                Thread.Sleep(400);
            }

            // Launch Main App Engine Process
            try
            {
                string engineExe = Path.Combine(appFolder, "EditPhotoEngine.exe");
                if (File.Exists(engineExe))
                {
                    Process.Start(engineExe);
                }
            }
            catch { }

            splash.Close();
        }

        static void KillProcess(string procName)
        {
            try
            {
                Process[] procs = Process.GetProcessesByName(procName);
                foreach (Process p in procs)
                {
                    try { p.Kill(); p.WaitForExit(2000); } catch { }
                }
            }
            catch { }
        }

        static void ExtractAndOverwrite(string zipPath, string targetDir)
        {
            try {
                using (ZipArchive archive = ZipFile.OpenRead(zipPath)) {
                    foreach (ZipArchiveEntry entry in archive.Entries) {
                        if (string.IsNullOrEmpty(entry.Name)) continue;
                        try {
                            string destinationPath = Path.Combine(targetDir, entry.FullName);
                            string dirName = Path.GetDirectoryName(destinationPath);
                            if (!Directory.Exists(dirName)) Directory.CreateDirectory(dirName);
                            entry.ExtractToFile(destinationPath, true);
                        }
                        catch {
                            // Ignore locked files currently in use by running process
                        }
                    }
                }
            }
            catch { }
        }

        static string GetInstalledVersion(string folder)
        {
            try {
                string path = Path.Combine(folder, "version.json");
                if (File.Exists(path)) {
                    string json = File.ReadAllText(path);
                    string ver = ExtractJsonValue(json, "latestVersion");
                    if (!string.IsNullOrEmpty(ver)) return ver;
                }
            } catch { }
            return "2.0.1";
        }

        static string ExtractJsonValue(string json, string key)
        {
            try {
                int idx = json.IndexOf("\"" + key + "\"");
                if (idx == -1) return null;
                int colonIdx = json.IndexOf(":", idx);
                if (colonIdx == -1) return null;
                int quoteStart = json.IndexOf("\"", colonIdx);
                if (quoteStart == -1) return null;
                int quoteEnd = json.IndexOf("\"", quoteStart + 1);
                if (quoteEnd == -1) return null;
                return json.Substring(quoteStart + 1, quoteEnd - quoteStart - 1);
            }
            catch { return null; }
        }
    }
}
