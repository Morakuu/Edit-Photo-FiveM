using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.IO.Compression;
using System.Net;
using System.Reflection;
using System.Threading;
using System.Windows.Forms;

namespace FiveMPhotoEditorPatcher
{
    // ===================================================================
    //  SPLASH FORM  (UI Thread)
    // ===================================================================
    public class PatcherForm : Form
    {
        private Label  lblStatus;
        private Label  lblTitle;
        private Label  lblSub;
        private Label  lblFooter;
        private int    _progress  = 0;
        private string _changelog = "Wczytywanie listy zmian...";

        public PatcherForm()
        {
            FormBorderStyle = FormBorderStyle.None;
            StartPosition   = FormStartPosition.CenterScreen;
            Size            = new Size(800, 460);
            BackColor       = Color.FromArgb(10, 10, 11);
            TopMost         = true;
            DoubleBuffered  = true;

            lblTitle = new Label {
                Text      = "EDIT PHOTO FIVEM",
                Font      = new Font("Segoe UI", 20f, FontStyle.Bold),
                ForeColor = Color.White,
                Location  = new Point(35, 25),
                AutoSize  = true
            };
            Controls.Add(lblTitle);

            lblSub = new Label {
                Text      = "SYSTEM AUTOMATYCZNYCH AKTUALIZACJI",
                Font      = new Font("Segoe UI", 9f, FontStyle.Bold),
                ForeColor = Color.FromArgb(70, 190, 255),
                Location  = new Point(37, 62),
                AutoSize  = true
            };
            Controls.Add(lblSub);

            lblStatus = new Label {
                Text      = "Sprawdzanie dostępności aktualizacji...",
                Font      = new Font("Segoe UI", 9.5f),
                ForeColor = Color.FromArgb(161, 161, 170),
                Location  = new Point(50, 285),
                Size      = new Size(450, 25),
                TextAlign = ContentAlignment.MiddleCenter
            };
            Controls.Add(lblStatus);

            lblFooter = new Label {
                Text      = "Edit Photo FiveM • Created by Suslowatyy",
                Font      = new Font("Segoe UI", 8.5f),
                ForeColor = Color.FromArgb(100, 116, 139),
                Location  = new Point(20, 425),
                AutoSize  = true
            };
            Controls.Add(lblFooter);
        }

        // Bezpieczne wywołanie z dowolnego wątku
        public void SetStatus(string text, int pct)
        {
            if (IsDisposed) return;
            if (InvokeRequired) {
                BeginInvoke(new Action(() => SetStatus(text, pct)));
                return;
            }
            lblStatus.Text = text;
            _progress      = Math.Max(0, Math.Min(100, pct));
            Invalidate();
        }

        public void SetChangelog(string cl)
        {
            if (IsDisposed) return;
            if (InvokeRequired) { BeginInvoke(new Action(() => SetChangelog(cl))); return; }
            _changelog = cl;
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            // Nagłówek sekcji
            using (var f = new Font("Segoe UI", 13, FontStyle.Bold))
            using (var b = new SolidBrush(Color.FromArgb(244, 244, 245))) {
                var sf = new StringFormat { Alignment = StringAlignment.Center };
                g.DrawString("Pobieranie i Instalowanie Aktualizacji", f, b, new PointF(270, 130), sf);
            }

            // Pasek postępu — tło
            var track = new Rectangle(50, 315, 440, 18);
            using (var gp = Rounded(track, 9))
            using (var br = new SolidBrush(Color.FromArgb(18, 18, 22)))
            using (var pe = new Pen(Color.FromArgb(40, 40, 50), 1)) {
                g.FillPath(br, gp);
                g.DrawPath(pe, gp);
            }

            // Pasek postępu — wypełnienie
            if (_progress > 0) {
                int w = Math.Max(18, (int)(440f * _progress / 100f));
                var fill = new Rectangle(50, 315, w, 18);
                using (var gp = Rounded(fill, 9))
                using (var lgb = new LinearGradientBrush(fill,
                    Color.FromArgb(24, 150, 220), Color.FromArgb(70, 190, 255), 0f))
                    g.FillPath(lgb, gp);
            }

            // Procenty
            using (var f = new Font("Segoe UI", 8f, FontStyle.Bold))
            using (var b = new SolidBrush(Color.FromArgb(70, 190, 255))) {
                var sf = new StringFormat { Alignment = StringAlignment.Center };
                g.DrawString(_progress + "%", f, b, new PointF(270, 338), sf);
            }

            // Panel changelogu (prawa strona)
            var panel = new Rectangle(520, 110, 250, 290);
            using (var gp = Rounded(panel, 12))
            using (var br = new SolidBrush(Color.FromArgb(18, 18, 22)))
            using (var pe = new Pen(Color.FromArgb(40, 40, 50), 1)) {
                g.FillPath(br, gp);
                g.DrawPath(pe, gp);
            }
            using (var f = new Font("Segoe UI", 8f))
            using (var b = new SolidBrush(Color.FromArgb(180, 180, 180)))
                g.DrawString("[Nowości]\n\n" + _changelog, f, b, new RectangleF(532, 120, 228, 270));

            // Linia świetlna na dole
            using (var lgb = new LinearGradientBrush(new Rectangle(0, 457, 800, 3),
                Color.Transparent, Color.FromArgb(70, 190, 255), 0f))
                g.FillRectangle(lgb, 0, 457, 800, 3);

            // Obramowanie
            g.DrawRectangle(new Pen(Color.FromArgb(40, 40, 50), 1), 0, 0, Width - 1, Height - 1);
        }

        static GraphicsPath Rounded(Rectangle r, int rad) {
            var p = new GraphicsPath(); int d = rad * 2;
            p.AddArc(r.X, r.Y, d, d, 180, 90);
            p.AddArc(r.Right - d, r.Y, d, d, 270, 90);
            p.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
            p.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
            p.CloseFigure(); return p;
        }
    }

    // ===================================================================
    //  MAIN PROGRAM
    // ===================================================================
    class Program
    {
        const string VERSION_URL  = "https://api.github.com/repos/Morakuu/Edit-Photo-FiveM/contents/version.json";
        const string DOWNLOAD_URL = "https://api.github.com/repos/Morakuu/Edit-Photo-FiveM/contents/EditPhotoFiveM-Update.zip";

        static PatcherForm _splash;
        static string      _appFolder;

        [STAThread]
        static void Main(string[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            _splash = new PatcherForm();
            _splash.Show();

            // Folder aplikacji ustalony na podstawie lokalizacji EXE
            _appFolder = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
            if (string.IsNullOrEmpty(_appFolder)) _appFolder = Application.StartupPath;

            // Uruchom logikę aktualizacji na wątku w tle — UI thread zostaje wolny
            var worker = new Thread(UpdateWorker) { IsBackground = true };
            worker.Start();

            // UI thread obsługuje zdarzenia (odświeżanie okna, animacje)
            Application.Run(_splash);
        }

        // ===================================================================
        //  WĄTEK W TLE — logika pobierania i aktualizacji
        // ===================================================================
        static void UpdateWorker()
        {
            try
            {
                _splash.SetStatus("Sprawdzanie dostępności aktualizacji...", 5);
                Thread.Sleep(300);

                // TLS 1.2
                try { ServicePointManager.SecurityProtocol =
                    (SecurityProtocolType)3072 | (SecurityProtocolType)768 | SecurityProtocolType.Tls; }
                catch { }

                // Zabij silnik jeśli działa
                KillProcess("EditPhotoEngine");

                // Odczytaj lokalną wersję
                string localVer = ReadLocalVersion(_appFolder);
                _splash.SetStatus("Zainstalowana: v" + localVer + "  |  Łączenie z serwerem...", 10);

                // ---- Krok 1: Sprawdź dostępną wersję ----
                string remoteVer       = localVer;
                string remoteChangelog = "";

                try {
                    string json = HttpGet(VERSION_URL + "?nocache=" + DateTime.Now.Ticks, 15000);
                    string v    = ParseJson(json, "latestVersion");
                    string cl   = ParseJson(json, "changelog");
                    if (!string.IsNullOrEmpty(v))  remoteVer       = v.Trim();
                    if (!string.IsNullOrEmpty(cl)) remoteChangelog = cl;

                    _splash.SetStatus("Dostępna: v" + remoteVer + "  |  Zainstalowana: v" + localVer, 25);
                    if (!string.IsNullOrEmpty(remoteChangelog))
                        _splash.SetChangelog(remoteChangelog.Replace("\\n", "\n"));
                }
                catch (Exception ex) {
                    _splash.SetStatus("Brak połączenia z serwerem: " + ex.Message, 25);
                    Thread.Sleep(2000);
                    Finish();
                    return;
                }

                // ---- Krok 2: Porównaj wersje ----
                if (remoteVer == localVer) {
                    _splash.SetStatus("Aplikacja jest aktualna (v" + localVer + "). Uruchamianie...", 100);
                    Thread.Sleep(800);
                    Finish();
                    return;
                }

                // ---- Krok 3: Pobierz paczkę aktualizacji ----
                _splash.SetStatus("Znaleziono aktualizację v" + remoteVer + "! Pobieranie...", 30);

                string tempZip    = Path.Combine(Path.GetTempPath(),
                    "EditPhotoFiveM-Update-" + DateTime.Now.Ticks + ".zip");
                bool   downloaded = false;

                try {
                    var req = (HttpWebRequest)WebRequest.Create(DOWNLOAD_URL + "?nocache=" + DateTime.Now.Ticks);
                    req.UserAgent                    = "EditPhotoFiveM-Patcher/2.0";
                    req.Accept                       = "application/vnd.github.v3.raw";
                    req.AllowAutoRedirect            = true;
                    req.MaximumAutomaticRedirections = 10;
                    req.Timeout                      = 180000;

                    using (var resp   = req.GetResponse())
                    using (var stream = resp.GetResponseStream())
                    using (var fs     = new FileStream(tempZip, FileMode.Create, FileAccess.Write))
                    {
                        long total = resp.ContentLength;
                        long got   = 0;
                        var  buf   = new byte[65536];
                        int  read;

                        while ((read = stream.Read(buf, 0, buf.Length)) > 0)
                        {
                            fs.Write(buf, 0, read);
                            got += read;
                            int pct          = 30 + (int)(got * 55.0 / Math.Max(total, 1));
                            string kb        = (got / 1024) + " KB";
                            string total_kb  = total > 0 ? " / " + (total / 1024) + " KB" : "";
                            _splash.SetStatus("Pobieranie aktualizacji v" + remoteVer + "... " + kb + total_kb, pct);
                        }
                    }

                    if (File.Exists(tempZip) && new FileInfo(tempZip).Length > 1000)
                        downloaded = true;
                }
                catch (Exception ex) {
                    _splash.SetStatus("Błąd pobierania: " + ex.Message, 50);
                    Thread.Sleep(2500);
                }

                // ---- Krok 4: Rozpakuj i nadpisz pliki ----
                if (downloaded) {
                    _splash.SetStatus("Instalowanie aktualizacji v" + remoteVer + "...", 88);
                    Thread.Sleep(200);

                    try {
                        using (var archive = ZipFile.OpenRead(tempZip)) {
                            foreach (var entry in archive.Entries) {
                                if (string.IsNullOrEmpty(entry.Name)) continue;
                                string dest = Path.Combine(_appFolder, entry.FullName);
                                string dir  = Path.GetDirectoryName(dest);
                                if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir))
                                    Directory.CreateDirectory(dir);
                                try { entry.ExtractToFile(dest, overwrite: true); }
                                catch { /* zablokowany plik (np. uruchomiony EXE) – pomiń */ }
                            }
                        }
                    }
                    catch { }

                    // Zapisz nową wersję do version.json
                    try {
                        File.WriteAllText(Path.Combine(_appFolder, "version.json"),
                            "{\n  \"latestVersion\": \"" + remoteVer + "\",\n  \"hasUpdate\": false,\n  \"downloadUrl\": \"\",\n  \"changelog\": \"\"\n}");
                    }
                    catch { }

                    try { File.Delete(tempZip); } catch { }

                    _splash.SetStatus("✓ Zainstalowano v" + remoteVer + "! Uruchamianie edytora...", 100);
                    Thread.Sleep(1000);
                }
                else {
                    _splash.SetStatus("Nie pobrano aktualizacji. Uruchamianie bieżącej wersji...", 100);
                    Thread.Sleep(1200);
                }
            }
            catch (Exception ex) {
                try { _splash.SetStatus("Błąd: " + ex.Message, 100); } catch { }
                Thread.Sleep(1500);
            }

            Finish();
        }

        // ===================================================================
        //  HELPERS
        // ===================================================================
        static void Finish()
        {
            try {
                string exe = Path.Combine(_appFolder, "EditPhotoEngine.exe");
                if (File.Exists(exe)) Process.Start(exe);
            }
            catch { }

            try {
                if (_splash != null && !_splash.IsDisposed)
                    _splash.Invoke(new Action(() => Application.Exit()));
            }
            catch { }
        }

        static string HttpGet(string url, int timeoutMs)
        {
            var req = (HttpWebRequest)WebRequest.Create(url);
            req.UserAgent         = "EditPhotoFiveM-Patcher/2.0";
            req.Accept            = "application/vnd.github.v3.raw";
            req.AllowAutoRedirect = true;
            req.Timeout           = timeoutMs;
            using (var resp = req.GetResponse())
            using (var sr   = new StreamReader(resp.GetResponseStream()))
                return sr.ReadToEnd();
        }

        static void KillProcess(string name)
        {
            try {
                foreach (var p in Process.GetProcessesByName(name))
                    try { p.Kill(); p.WaitForExit(2000); } catch { }
            }
            catch { }
        }

        static string ReadLocalVersion(string folder)
        {
            try {
                string path = Path.Combine(folder, "version.json");
                if (!File.Exists(path)) return "0.0.0";
                string v = ParseJson(File.ReadAllText(path), "latestVersion");
                return string.IsNullOrEmpty(v) ? "0.0.0" : v.Trim();
            }
            catch { return "0.0.0"; }
        }

        static string ParseJson(string json, string key)
        {
            try {
                int ki = json.IndexOf("\"" + key + "\"");
                if (ki < 0) return null;
                int ci = json.IndexOf(":", ki + key.Length + 2);
                if (ci < 0) return null;
                int qi = json.IndexOf("\"", ci);
                if (qi < 0) return null;
                int qe = json.IndexOf("\"", qi + 1);
                if (qe < 0) return null;
                return json.Substring(qi + 1, qe - qi - 1);
            }
            catch { return null; }
        }
    }
}
