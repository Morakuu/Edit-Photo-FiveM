using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.IO.Compression;
using System.Reflection;
using System.Threading;
using System.Windows.Forms;

namespace EditPhotoFiveMInstaller
{
    public class InstallerForm : Form
    {
        private Label lblTitle;
        private Label lblSubTitle;
        private Label lblPathHeader;
        private TextBox txtPath;
        private Button btnBrowse;
        private Label lblDiskSpace;
        private CheckBox chkDesktopShortcut;
        private CheckBox chkLaunchApp;
        private Button btnInstall;
        private ProgressBar pbInstall;
        private Label lblStatus;
        private Label lblFooter;

        private string selectedInstallPath;

        public InstallerForm()
        {
            this.FormBorderStyle = FormBorderStyle.None;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Size = new Size(720, 480);
            this.BackColor = Color.FromArgb(10, 10, 11);
            this.TopMost = true;
            this.DoubleBuffered = true;

            // Default Install Path: Prefer D:\ or C:\EditPhotoFiveM
            string defaultDrive = "C:\\";
            DriveInfo[] drives = DriveInfo.GetDrives();
            foreach (DriveInfo drive in drives) {
                if (drive.IsReady && drive.DriveType == DriveType.Fixed && drive.Name.StartsWith("D", StringComparison.OrdinalIgnoreCase)) {
                    defaultDrive = "D:\\";
                    break;
                }
            }
            selectedInstallPath = Path.Combine(defaultDrive, "EditPhotoFiveM");

            // Header Title
            lblTitle = new Label();
            lblTitle.Text = "EDIT PHOTO FIVEM";
            lblTitle.Font = new Font("Segoe UI", 22f, FontStyle.Bold);
            lblTitle.ForeColor = Color.White;
            lblTitle.Location = new Point(35, 25);
            lblTitle.AutoSize = true;
            this.Controls.Add(lblTitle);

            // Subtitle
            lblSubTitle = new Label();
            lblSubTitle.Text = "INSTALATOR APLIKACJI • CREATED BY SUSLOWATYY";
            lblSubTitle.Font = new Font("Segoe UI", 9f, FontStyle.Bold);
            lblSubTitle.ForeColor = Color.FromArgb(70, 190, 255);
            lblSubTitle.Location = new Point(37, 63);
            lblSubTitle.AutoSize = true;
            this.Controls.Add(lblSubTitle);

            // Path Header
            lblPathHeader = new Label();
            lblPathHeader.Text = "Wybierz dysk i folder docelowy dla instalacji:";
            lblPathHeader.Font = new Font("Segoe UI", 9.5f, FontStyle.Bold);
            lblPathHeader.ForeColor = Color.FromArgb(220, 220, 225);
            lblPathHeader.Location = new Point(40, 120);
            lblPathHeader.AutoSize = true;
            this.Controls.Add(lblPathHeader);

            // Path Input TextBox
            txtPath = new TextBox();
            txtPath.Text = selectedInstallPath;
            txtPath.Font = new Font("Segoe UI", 10f, FontStyle.Regular);
            txtPath.BackColor = Color.FromArgb(20, 20, 26);
            txtPath.ForeColor = Color.White;
            txtPath.BorderStyle = BorderStyle.FixedSingle;
            txtPath.Location = new Point(40, 148);
            txtPath.Size = new Size(500, 28);
            txtPath.TextChanged += (s, e) => {
                selectedInstallPath = txtPath.Text.Trim();
                UpdateDiskSpaceInfo();
            };
            this.Controls.Add(txtPath);

            // Browse Button
            btnBrowse = new Button();
            btnBrowse.Text = "Przeglądaj...";
            btnBrowse.Font = new Font("Segoe UI", 9f, FontStyle.Bold);
            btnBrowse.BackColor = Color.FromArgb(30, 30, 40);
            btnBrowse.ForeColor = Color.FromArgb(70, 190, 255);
            btnBrowse.FlatStyle = FlatStyle.Flat;
            btnBrowse.FlatAppearance.BorderColor = Color.FromArgb(70, 190, 255);
            btnBrowse.Location = new Point(555, 146);
            btnBrowse.Size = new Size(125, 30);
            btnBrowse.Cursor = Cursors.Hand;
            btnBrowse.Click += BtnBrowse_Click;
            this.Controls.Add(btnBrowse);

            // Disk Space Info Label
            lblDiskSpace = new Label();
            lblDiskSpace.Font = new Font("Segoe UI", 8.5f, FontStyle.Regular);
            lblDiskSpace.ForeColor = Color.FromArgb(161, 161, 170);
            lblDiskSpace.Location = new Point(40, 182);
            lblDiskSpace.AutoSize = true;
            this.Controls.Add(lblDiskSpace);
            UpdateDiskSpaceInfo();

            // Options Checkboxes
            chkDesktopShortcut = new CheckBox();
            chkDesktopShortcut.Text = "Utwórz skrót do aplikacji na Pulpicie";
            chkDesktopShortcut.Checked = true;
            chkDesktopShortcut.Font = new Font("Segoe UI", 9.5f, FontStyle.Regular);
            chkDesktopShortcut.ForeColor = Color.White;
            chkDesktopShortcut.Location = new Point(40, 220);
            chkDesktopShortcut.AutoSize = true;
            this.Controls.Add(chkDesktopShortcut);

            chkLaunchApp = new CheckBox();
            chkLaunchApp.Text = "Uruchom edytor zaraz po zakończeniu instalacji";
            chkLaunchApp.Checked = true;
            chkLaunchApp.Font = new Font("Segoe UI", 9.5f, FontStyle.Regular);
            chkLaunchApp.ForeColor = Color.White;
            chkLaunchApp.Location = new Point(40, 250);
            chkLaunchApp.AutoSize = true;
            this.Controls.Add(chkLaunchApp);

            // Status Text
            lblStatus = new Label();
            lblStatus.Text = "Gotowy do instalacji. Kliknij przycisk poniżej, aby rozpocząć.";
            lblStatus.Font = new Font("Segoe UI", 9f, FontStyle.Regular);
            lblStatus.ForeColor = Color.FromArgb(161, 161, 170);
            lblStatus.Location = new Point(40, 300);
            lblStatus.Size = new Size(640, 22);
            this.Controls.Add(lblStatus);

            // Progress Bar Track
            pbInstall = new ProgressBar();
            pbInstall.Location = new Point(40, 325);
            pbInstall.Size = new Size(640, 18);
            pbInstall.Value = 0;
            this.Controls.Add(pbInstall);

            // Install Button
            btnInstall = new Button();
            btnInstall.Text = "ZAINSTALUJ TERAZ";
            btnInstall.Font = new Font("Segoe UI", 11f, FontStyle.Bold);
            btnInstall.BackColor = Color.FromArgb(70, 190, 255);
            btnInstall.ForeColor = Color.FromArgb(10, 10, 11);
            btnInstall.FlatStyle = FlatStyle.Flat;
            btnInstall.FlatAppearance.BorderSize = 0;
            btnInstall.Location = new Point(40, 365);
            btnInstall.Size = new Size(640, 44);
            btnInstall.Cursor = Cursors.Hand;
            btnInstall.Click += BtnInstall_Click;
            this.Controls.Add(btnInstall);

            // Footer
            lblFooter = new Label();
            lblFooter.Text = "Edit Photo FiveM Installer v2.0 • Wszystkie prawa zastrzeżone";
            lblFooter.Font = new Font("Segoe UI", 8.5f, FontStyle.Regular);
            lblFooter.ForeColor = Color.FromArgb(100, 116, 139);
            lblFooter.Location = new Point(20, 445);
            lblFooter.AutoSize = true;
            this.Controls.Add(lblFooter);

            // Close X Button
            Button btnClose = new Button();
            btnClose.Text = "✕";
            btnClose.Font = new Font("Segoe UI", 10f, FontStyle.Bold);
            btnClose.ForeColor = Color.FromArgb(161, 161, 170);
            btnClose.BackColor = Color.Transparent;
            btnClose.FlatStyle = FlatStyle.Flat;
            btnClose.FlatAppearance.BorderSize = 0;
            btnClose.Location = new Point(675, 15);
            btnClose.Size = new Size(30, 30);
            btnClose.Cursor = Cursors.Hand;
            btnClose.Click += (s, e) => this.Close();
            this.Controls.Add(btnClose);
        }

        private void BtnBrowse_Click(object sender, EventArgs e)
        {
            using (FolderBrowserDialog dialog = new FolderBrowserDialog())
            {
                dialog.Description = "Wybierz dysk i folder, w którym ma zostać zainstalowana aplikacja Edit Photo FiveM:";
                dialog.ShowNewFolderButton = true;
                if (dialog.ShowDialog() == DialogResult.OK && !string.IsNullOrWhiteSpace(dialog.SelectedPath))
                {
                    selectedInstallPath = Path.Combine(dialog.SelectedPath, "EditPhotoFiveM");
                    txtPath.Text = selectedInstallPath;
                    UpdateDiskSpaceInfo();
                }
            }
        }

        private void UpdateDiskSpaceInfo()
        {
            try
            {
                string root = Path.GetPathRoot(selectedInstallPath);
                if (!string.IsNullOrEmpty(root))
                {
                    DriveInfo info = new DriveInfo(root);
                    double freeGB = Math.Round((double)info.AvailableFreeSpace / (1024 * 1024 * 1024), 2);
                    lblDiskSpace.Text = string.Format("Dysk docelowy: {0} (Wolne miejsce: {1} GB)", root, freeGB);
                    return;
                }
            }
            catch { }
            lblDiskSpace.Text = "Wskazano ścieżkę instalacji";
        }

        private void BtnInstall_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(selectedInstallPath))
            {
                MessageBox.Show("Proszę podać prawidłową ścieżkę instalacji.", "Wybór Dysku", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            btnInstall.Enabled = false;
            btnBrowse.Enabled = false;
            txtPath.Enabled = false;

            ThreadPool.QueueUserWorkItem((o) => {
                PerformInstallation();
            });
        }

        private void PerformInstallation()
        {
            try
            {
                UpdateStatusUI("Zwalnianie uruchomionych procesów...", 10);
                KillProcess("FiveMPhotoEditor");
                KillProcess("EditPhotoEngine");
                KillProcess("Patcher");

                UpdateStatusUI("Tworzenie folderu docelowego na wskazanym dysku...", 25);
                if (!Directory.Exists(selectedInstallPath))
                {
                    Directory.CreateDirectory(selectedInstallPath);
                }

                UpdateStatusUI("Rozpakowywanie składników edytora i patchera...", 50);

                Assembly asm = Assembly.GetExecutingAssembly();
                using (Stream stream = asm.GetManifestResourceStream("EditPhotoFiveM-Payload.zip"))
                {
                    if (stream != null)
                    {
                        string tempZip = Path.Combine(Path.GetTempPath(), "EditPhotoFiveM-InstallPayload.zip");
                        if (File.Exists(tempZip)) File.Delete(tempZip);

                        using (FileStream fs = File.Create(tempZip))
                        {
                            stream.CopyTo(fs);
                        }

                        UpdateStatusUI("Wypakowywanie plików do " + selectedInstallPath + "...", 75);
                        ExtractZipToDirectory(tempZip, selectedInstallPath);

                        try { File.Delete(tempZip); } catch { }
                    }
                    else
                    {
                        // Fallback if Zip is alongside installer executable
                        string localZip = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "EditPhotoFiveM-Payload.zip");
                        if (File.Exists(localZip))
                        {
                            ExtractZipToDirectory(localZip, selectedInstallPath);
                        }
                    }
                }

                // Create Desktop Shortcut if checked
                if (chkDesktopShortcut.Checked)
                {
                    UpdateStatusUI("Tworzenie skrótu na Pulpicie...", 90);
                    CreateDesktopShortcut(selectedInstallPath);
                }

                UpdateStatusUI("Instalacja zakończona sukcesem! Aplikacja jest gotowa.", 100);
                Thread.Sleep(800);

                // Auto launch app if checked
                if (chkLaunchApp.Checked)
                {
                    string patcherExe = Path.Combine(selectedInstallPath, "Patcher.exe");
                    if (!File.Exists(patcherExe)) patcherExe = Path.Combine(selectedInstallPath, "FiveMPhotoEditor.exe");
                    if (File.Exists(patcherExe))
                    {
                        Process.Start(patcherExe);
                    }
                }

                this.Invoke(new Action(() => this.Close()));
            }
            catch (Exception ex)
            {
                UpdateStatusUI("Błąd podczas instalacji: " + ex.Message, 0);
                this.Invoke(new Action(() => {
                    btnInstall.Enabled = true;
                    btnBrowse.Enabled = true;
                    txtPath.Enabled = true;
                }));
            }
        }

        private void UpdateStatusUI(string text, int progress)
        {
            if (this.InvokeRequired)
            {
                this.Invoke(new Action(() => UpdateStatusUI(text, progress)));
                return;
            }
            lblStatus.Text = text;
            pbInstall.Value = Math.Min(100, Math.Max(0, progress));
        }

        private void KillProcess(string procName)
        {
            try {
                Process[] procs = Process.GetProcessesByName(procName);
                foreach (Process p in procs) {
                    try { p.Kill(); p.WaitForExit(1500); } catch { }
                }
            }
            catch { }
        }

        private void ExtractZipToDirectory(string zipPath, string targetDir)
        {
            using (ZipArchive archive = ZipFile.OpenRead(zipPath)) {
                foreach (ZipArchiveEntry entry in archive.Entries) {
                    if (string.IsNullOrEmpty(entry.Name)) continue;
                    string destPath = Path.Combine(targetDir, entry.FullName);
                    string dirName = Path.GetDirectoryName(destPath);
                    if (!Directory.Exists(dirName)) Directory.CreateDirectory(dirName);
                    entry.ExtractToFile(destPath, true);
                }
            }
        }

        private void CreateDesktopShortcut(string targetFolder)
        {
            try
            {
                string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
                string shortcutPath = Path.Combine(desktopPath, "Edit Photo FiveM.lnk");
                string targetExe = Path.Combine(targetFolder, "Patcher.exe");

                // Generate VBS script to create shortcut via Windows WScript.Shell
                string vbsScript = string.Format(@"
Set oWS = WScript.CreateObject(""WScript.Shell"")
sLinkFile = ""{0}""
Set oLink = oWS.CreateShortcut(sLinkFile)
oLink.TargetPath = ""{1}""
oLink.WorkingDirectory = ""{2}""
oLink.Description = ""Edit Photo FiveM - Created by Suslowatyy""
oLink.Save
", shortcutPath, targetExe, targetFolder);

                string tempVbs = Path.Combine(Path.GetTempPath(), "CreateShortcut.vbs");
                File.WriteAllText(tempVbs, vbsScript);

                Process p = Process.Start("wscript.exe", "\"" + tempVbs + "\"");
                p.WaitForExit(3000);
                try { File.Delete(tempVbs); } catch { }
            }
            catch { }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            // Bottom Sky-Blue Accent Line
            using (LinearGradientBrush glowLine = new LinearGradientBrush(new Rectangle(0, 477, 720, 3), Color.Transparent, Color.FromArgb(70, 190, 255), 0f))
            {
                g.FillRectangle(glowLine, 0, 477, 720, 3);
            }

            // Outer Border
            g.DrawRectangle(new Pen(Color.FromArgb(40, 40, 50), 1), 0, 0, this.Width - 1, this.Height - 1);
        }
    }

    class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new InstallerForm());
        }
    }
}
