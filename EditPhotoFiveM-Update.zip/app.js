// ============================================================
// EDIT PRO - GEMINI AI PHOTO EDITOR & QUANTV / ENB REMASTER
// ============================================================

// App State
const state = {
    camera: {
        zoom: 1.0,
        tilt: 0, // Roll
        pitch: 0,
        yaw: 0,
        panX: 0,
        panY: 0,
        fisheye: 0
    },
    gemini: {
        activePreset: 'none',
        enbBloom: 0,
        enbRaytrace: 0,
        wetRoads: 0,
        customPrompt: '',
        isGenerating: false
    },
    hudCleaner: {
        cleanMinimap: false,
        cleanStatus: false,
        cleanSpeedo: false,
        cleanCrosshair: false,
        cleanWatermarks: false,
        patchMode: false, // Manual retouch brush mode
        brushSize: 25,
        patches: [] // Array of {x, y, radius} normalized points
    },
    filters: {
        active: 'natural'
    },
    adjustments: {
        exposure: 0,
        brightness: 0,
        contrast: 0,
        saturation: 0,
        temp: 0,
        vignette: 0,
        grain: 0,
        aberration: 0
    },
    dof: {
        type: 'none',
        blur: 15,
        size: 30,
        angle: 0,
        focusX: 0.5,
        focusY: 0.5
    },
    export: {
        format: 'png',
        quality: 95
    }
};

// Global Variables
let originalImage = null;
let isFisheyeDragging = false;
let isPanning = false;
let isPatching = false;
let startPanX = 0;
let startPanY = 0;
let noiseCanvas = null;

// Text Overlay State
const textOverlayState = {
    overlays: [],   // { text, sub, style, pos, color }
    textStyle: 'location',
    pos: 'bottom-left',
    color: '#ffffff'
};

// DOM Elements
const dropzone = document.getElementById('dropzone');
const fileInput = document.getElementById('file-input');
const previewContainer = document.getElementById('preview-container');
const editorCanvas = document.getElementById('editor-canvas');
const ctx = editorCanvas.getContext('2d');
const dofFocusMarker = document.getElementById('dof-focus-marker');
const btnLoadDemo = document.getElementById('btn-load-demo');
const btnResetAllAdjust = document.getElementById('btn-reset-all-adjust');
const btnDownload = document.getElementById('btn-download');
const btnCopyClipboard = document.getElementById('btn-copy-clipboard');

// Initialize Sliders Mapping
const sliders = [
    { id: 'range-zoom', path: 'camera.zoom', valId: 'val-zoom', suffix: 'x', isFloat: true },
    { id: 'range-tilt', path: 'camera.tilt', valId: 'val-tilt', suffix: '°' },
    { id: 'range-pitch', path: 'camera.pitch', valId: 'val-pitch', suffix: '°' },
    { id: 'range-yaw', path: 'camera.yaw', valId: 'val-yaw', suffix: '°' },
    { id: 'range-pan-x', path: 'camera.panX', valId: 'val-pan-x', suffix: 'px' },
    { id: 'range-pan-y', path: 'camera.panY', valId: 'val-pan-y', suffix: 'px' },
    { id: 'range-fisheye', path: 'camera.fisheye', valId: 'val-fisheye', suffix: '' },
    
    // Gemini & QuantV sliders
    { id: 'range-enb-bloom', path: 'gemini.enbBloom', valId: 'val-enb-bloom', suffix: '%' },
    { id: 'range-enb-raytrace', path: 'gemini.enbRaytrace', valId: 'val-enb-raytrace', suffix: '%' },
    { id: 'range-wet-roads', path: 'gemini.wetRoads', valId: 'val-wet-roads', suffix: '%' },
    
    // Adjustments
    { id: 'range-exposure', path: 'adjustments.exposure', valId: 'val-exposure', suffix: '%' },
    { id: 'range-contrast', path: 'adjustments.contrast', valId: 'val-contrast', suffix: '%' },
    { id: 'range-saturation', path: 'adjustments.saturation', valId: 'val-saturation', suffix: '%' },
    { id: 'range-temp', path: 'adjustments.temp', valId: 'val-temp', suffix: '' },
    { id: 'range-vignette', path: 'adjustments.vignette', valId: 'val-vignette', suffix: '%' },
    { id: 'range-grain', path: 'adjustments.grain', valId: 'val-grain', suffix: '%' },
    { id: 'range-aberration', path: 'adjustments.aberration', valId: 'val-aberration', suffix: 'px', isFloat: true },
    
    // DoF
    { id: 'range-dof-blur', path: 'dof.blur', valId: 'val-dof-blur', suffix: 'px' },
    { id: 'range-dof-size', path: 'dof.size', valId: 'val-dof-size', suffix: '%' },
    { id: 'range-dof-angle', path: 'dof.angle', valId: 'val-dof-angle', suffix: '°' },
    
    // Export
    { id: 'range-jpg-quality', path: 'export.quality', valId: 'val-jpg-quality', suffix: '%' },
    
    // Brush size
    { id: 'range-brush-size', path: 'hudCleaner.brushSize', valId: 'val-brush-size', suffix: 'px' }
];

// Initialize Application
function init() {
    initDiscordAuth();
    setupAdminPanel();
    setupPatcherUpdater();
    initNoiseCanvas();
    setupTabs();
    setupSliders();
    setupPresets();
    setupGeminiEngine();
    setupHudCleaner();
    setupDofToggles();
    setupExportToggles();
    setupClipboardAndDragDrop();
    setupMouseInteraction();
    setupTextOverlay();

    // Reset Buttons
    if (btnResetAllAdjust) btnResetAllAdjust.addEventListener('click', resetAllAdjustments);
    btnLoadDemo.addEventListener('click', loadDemoImage);
    document.getElementById('btn-reset-all').addEventListener('click', hardResetAll);

    // Export Buttons
    btnDownload.addEventListener('click', downloadImage);
    btnCopyClipboard.addEventListener('click', copyToClipboard);

    resizeSlidersBasedOnImage();
}

// Generate Noise Pattern Canvas
function initNoiseCanvas() {
    noiseCanvas = document.createElement('canvas');
    noiseCanvas.width = 256;
    noiseCanvas.height = 256;
    const nCtx = noiseCanvas.getContext('2d');
    const nData = nCtx.createImageData(256, 256);
    const pixels = nData.data;
    for (let i = 0; i < pixels.length; i += 4) {
        const val = Math.floor(Math.random() * 255);
        pixels[i] = val;
        pixels[i+1] = val;
        pixels[i+2] = val;
        pixels[i+3] = 35; // Alpha
    }
    nCtx.putImageData(nData, 0, 0);
}

// Sidebar Tabs Navigation
function setupTabs() {
    const tabs = document.querySelectorAll('.tab-btn');
    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
            document.querySelectorAll('.tab-pane').forEach(pane => pane.classList.remove('active'));
            
            tab.classList.add('active');
            const paneId = `tab-${tab.dataset.tab}`;
            const paneEl = document.getElementById(paneId);
            if (paneEl) paneEl.classList.add('active');
        });
    });
}

// Setup Sliders & Input Sync
function setupSliders() {
    sliders.forEach(config => {
        const el = document.getElementById(config.id);
        const valEl = document.getElementById(config.valId);
        if (!el) return;

        el.addEventListener('input', (e) => {
            const val = config.isFloat ? parseFloat(e.target.value) : parseInt(e.target.value, 10);
            setDeepValue(state, config.path, val);
            if (valEl) valEl.textContent = val + config.suffix;
            render();
        });
    });

    // Individual slider reset buttons
    document.querySelectorAll('.btn-reset').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const targetId = btn.dataset.target;
            const el = document.getElementById(targetId);
            if (!el) return;
            
            const defaultValue = el.getAttribute('value') || 0;
            el.value = defaultValue;
            el.dispatchEvent(new Event('input'));
        });
    });
}

// Helper to set nested object properties
function setDeepValue(obj, path, value) {
    const parts = path.split('.');
    let curr = obj;
    for (let i = 0; i < parts.length - 1; i++) {
        curr = curr[parts[i]];
    }
    curr[parts[parts.length - 1]] = value;
}

// Setup Timecycle Presets
function setupPresets() {
    const cards = document.querySelectorAll('.filter-card');
    cards.forEach(card => {
        card.addEventListener('click', () => {
            cards.forEach(c => c.classList.remove('active'));
            card.classList.add('active');
            state.filters.active = card.dataset.filter;
            render();
        });
    });
}

// ============================================================
// GEMINI AI & QUANTV REMASTER ENGINE
// ============================================================

function setupGeminiEngine() {
    const presetCards = document.querySelectorAll('.preset-card');
    presetCards.forEach(card => {
        card.addEventListener('click', () => {
            presetCards.forEach(c => {
                c.classList.remove('active');
                const dot = c.querySelector('.w-2.h-2');
                if (dot) dot.className = 'w-2 h-2 rounded-full bg-transparent';
            });
            card.classList.add('active');
            const dot = card.querySelector('.w-2.h-2');
            if (dot) dot.className = 'w-2 h-2 rounded-full bg-primary shadow-glow';

            state.gemini.activePreset = card.dataset.preset;
            applyGeminiPresetParameters(card.dataset.preset);
            render();
        });
    });

    const btnRunGemini = document.getElementById('btn-run-gemini');
    if (btnRunGemini) {
        btnRunGemini.addEventListener('click', runGeminiAIProcessing);
    }
}

function applyGeminiPresetParameters(preset) {
    switch (preset) {
        case 'none':
            setSliderValue('range-enb-bloom', 0);
            setSliderValue('range-enb-raytrace', 0);
            setSliderValue('range-wet-roads', 0);
            setSliderValue('range-contrast', 0);
            setSliderValue('range-exposure', 0);
            break;
        case 'quantv_ultra':
            setSliderValue('range-enb-bloom', 25);
            setSliderValue('range-enb-raytrace', 35);
            setSliderValue('range-wet-roads', 15);
            setSliderValue('range-contrast', 10);
            setSliderValue('range-exposure', 0);
            break;
        case 'nve_enb':
            setSliderValue('range-enb-bloom', 15);
            setSliderValue('range-enb-raytrace', 25);
            setSliderValue('range-wet-roads', 10);
            setSliderValue('range-contrast', 10);
            setSliderValue('range-temp', 5);
            break;
        case 'wet_reflections':
            setSliderValue('range-enb-bloom', 20);
            setSliderValue('range-enb-raytrace', 50);
            setSliderValue('range-wet-roads', 70);
            setSliderValue('range-contrast', 15);
            break;
        case 'cyberpunk_night':
            setSliderValue('range-enb-bloom', 35);
            setSliderValue('range-enb-raytrace', 45);
            setSliderValue('range-wet-roads', 35);
            setSliderValue('range-contrast', 20);
            setSliderValue('range-temp', -10);
            break;
    }
}

function setSliderValue(id, val) {
    const el = document.getElementById(id);
    if (el) {
        el.value = val;
        el.dispatchEvent(new Event('input'));
    }
}

function runGeminiAIProcessing() {
    if (!originalImage) return;

    const overlay = document.getElementById('ai-loading-overlay');
    const loadingText = document.getElementById('ai-loading-text');
    if (overlay) overlay.classList.remove('hidden');

    const promptText = document.getElementById('gemini-prompt-input').value.trim();

    if (loadingText) {
        loadingText.textContent = promptText ? 'Gemini AI: Generowanie efektów według instrukcji...' : 'Gemini AI: Renderowanie QuantV 3.0 & ENB Raytracing...';
    }

    setTimeout(() => {
        // Render Gemini AI remaster effects
        render();

        if (overlay) overlay.classList.add('hidden');
    }, 900);
}

// ============================================================
// SMART FIVE M & GTA V HUD CLEANER
// ============================================================

function setupHudCleaner() {
    const chkMinimap = document.getElementById('chk-clean-minimap');
    const chkStatus = document.getElementById('chk-clean-status');
    const chkSpeedo = document.getElementById('chk-clean-speedo');
    const chkCrosshair = document.getElementById('chk-clean-crosshair');
    const chkWatermarks = document.getElementById('chk-clean-watermarks');

    if (chkMinimap) chkMinimap.addEventListener('change', e => { state.hudCleaner.cleanMinimap = e.target.checked; render(); });
    if (chkStatus) chkStatus.addEventListener('change', e => { state.hudCleaner.cleanStatus = e.target.checked; render(); });
    if (chkSpeedo) chkSpeedo.addEventListener('change', e => { state.hudCleaner.cleanSpeedo = e.target.checked; render(); });
    if (chkCrosshair) chkCrosshair.addEventListener('change', e => { state.hudCleaner.cleanCrosshair = e.target.checked; render(); });
    if (chkWatermarks) chkWatermarks.addEventListener('change', e => { state.hudCleaner.cleanWatermarks = e.target.checked; render(); });

    const btnAutoClean = document.getElementById('btn-auto-clean-hud');
    if (btnAutoClean) btnAutoClean.addEventListener('click', () => { autoCleanHUD(); render(); });

    const btnPatchMode = document.getElementById('btn-toggle-patch-mode');
    const lblPatchMode = document.getElementById('lbl-patch-mode');
    if (btnPatchMode) {
        btnPatchMode.addEventListener('click', () => {
            state.hudCleaner.patchMode = !state.hudCleaner.patchMode;
            if (state.hudCleaner.patchMode) {
                btnPatchMode.classList.remove('btn-tactical-secondary');
                btnPatchMode.classList.add('btn-tactical-primary');
                if (lblPatchMode) lblPatchMode.textContent = 'Pędzel Aktywny (Kliknij na zdjęcie)';
                editorCanvas.classList.add('patch-mode-active');
            } else {
                btnPatchMode.classList.remove('btn-tactical-primary');
                btnPatchMode.classList.add('btn-tactical-secondary');
                if (lblPatchMode) lblPatchMode.textContent = 'Włącz Pędzel Retuszu';
                editorCanvas.classList.remove('patch-mode-active');
            }
        });
    }

    const btnClearPatches = document.getElementById('btn-clear-patches');
    if (btnClearPatches) {
        btnClearPatches.addEventListener('click', () => {
            state.hudCleaner.patches = [];
            render();
        });
    }
}

function autoCleanHUD() {
    state.hudCleaner.cleanMinimap = true;
    state.hudCleaner.cleanStatus = true;
    state.hudCleaner.cleanSpeedo = true;
    state.hudCleaner.cleanCrosshair = true;
    state.hudCleaner.cleanWatermarks = true;

    // Check checkboxes
    ['chk-clean-minimap', 'chk-clean-status', 'chk-clean-speedo', 'chk-clean-crosshair', 'chk-clean-watermarks'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.checked = true;
    });
}

// Inpaint / Retouch Game HUD regions directly on rendering context
function applyHudCleanerInpainting(canvas, renderCtx) {
    if (!originalImage) return;
    const W = canvas.width;
    const H = canvas.height;
    const hc = state.hudCleaner;

    // 1. Minimap & Radar (Bottom-Left Quadrant)
    if (hc.cleanMinimap) {
        const mx = 0;
        const my = Math.round(H * 0.65);
        const mw = Math.round(W * 0.28);
        const mh = Math.round(H * 0.35);
        smartContentAwareInpaint(renderCtx, mx, my, mw, mh, canvas);
    }

    // 2. Health & Status Bars (Bottom-Left)
    if (hc.cleanStatus && !hc.cleanMinimap) {
        const sx = 0;
        const sy = Math.round(H * 0.82);
        const sw = Math.round(W * 0.25);
        const sh = Math.round(H * 0.18);
        smartContentAwareInpaint(renderCtx, sx, sy, sw, sh, canvas);
    }

    // 3. Speedometer & Street text (Bottom-Right)
    if (hc.cleanSpeedo) {
        const spx = Math.round(W * 0.74);
        const spy = Math.round(H * 0.78);
        const spw = Math.round(W * 0.26);
        const sph = Math.round(H * 0.22);
        smartContentAwareInpaint(renderCtx, spx, spy, spw, sph, canvas);
    }

    // 4. Server Watermark / Logos (Top Right)
    if (hc.cleanWatermarks) {
        const wx = Math.round(W * 0.72);
        const wy = 0;
        const ww = Math.round(W * 0.28);
        const wh = Math.round(H * 0.14);
        smartContentAwareInpaint(renderCtx, wx, wy, ww, wh, canvas);
    }

    // 5. Crosshair (Center reticle)
    if (hc.cleanCrosshair) {
        const cx = Math.round(W * 0.5 - 15);
        const cy = Math.round(H * 0.5 - 15);
        smartContentAwareInpaint(renderCtx, cx, cy, 30, 30, canvas);
    }

    // 6. Manual Patch Points
    if (hc.patches.length > 0) {
        hc.patches.forEach(p => {
            const px = Math.round(p.x * W);
            const py = Math.round(p.y * H);
            const rad = Math.round(p.radius);
            smartContentAwareInpaint(renderCtx, px - rad, py - rad, rad * 2, rad * 2, canvas);
        });
    }
}

// Content-Aware Inpainting Algorithm: Smooth regional edge blend without rectangle pixel stretching
function smartContentAwareInpaint(ctx, x, y, w, h, canvas) {
    if (w <= 0 || h <= 0) return;
    const W = canvas.width;
    const H = canvas.height;

    // Clamp coordinates
    const rx = Math.max(0, x);
    const ry = Math.max(0, y);
    const rw = Math.min(W - rx, w);
    const rh = Math.min(H - ry, h);
    if (rw <= 0 || rh <= 0) return;

    ctx.save();
    
    // Smooth regional blur patch instead of stretching rectangle slices
    const patchCanvas = document.createElement('canvas');
    patchCanvas.width = rw;
    patchCanvas.height = rh;
    const pCtx = patchCanvas.getContext('2d');

    pCtx.filter = 'blur(16px)';
    pCtx.drawImage(canvas, rx, ry, rw, rh, 0, 0, rw, rh);

    ctx.globalAlpha = 0.85;
    ctx.drawImage(patchCanvas, rx, ry);

    ctx.restore();
}

// Setup DoF Toggles
function setupDofToggles() {
    const buttons = document.querySelectorAll('#dof-type-group .btn-toggle');
    const subControls = document.getElementById('dof-controls-sub');
    const angleContainer = document.getElementById('dof-angle-container');

    buttons.forEach(btn => {
        btn.addEventListener('click', () => {
            buttons.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');

            state.dof.type = btn.dataset.dofType;

            if (state.dof.type === 'none') {
                subControls.classList.add('hidden');
                dofFocusMarker.classList.add('hidden');
            } else {
                subControls.classList.remove('hidden');
                dofFocusMarker.classList.remove('hidden');
                if (state.dof.type === 'linear') {
                    angleContainer.classList.remove('hidden');
                } else {
                    angleContainer.classList.add('hidden');
                }
            }
            render();
        });
    });
}

// Setup Export Format Toggles
function setupExportToggles() {
    const buttons = document.querySelectorAll('#export-format-group .btn-toggle');
    const jpgContainer = document.getElementById('jpg-quality-container');

    buttons.forEach(btn => {
        btn.addEventListener('click', () => {
            buttons.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');

            state.export.format = btn.dataset.format;
            if (state.export.format === 'jpg') {
                jpgContainer.classList.remove('hidden');
            } else {
                jpgContainer.classList.add('hidden');
            }
        });
    });
}

// Clipboard & Drag and Drop Handling
function setupClipboardAndDragDrop() {
    window.addEventListener('paste', (e) => {
        const items = (e.clipboardData || e.originalEvent.clipboardData).items;
        for (const item of items) {
            if (item.type.indexOf('image') === 0) {
                const blob = item.getAsFile();
                loadImageFromFile(blob);
                break;
            }
        }
    });

    fileInput.addEventListener('change', (e) => {
        if (e.target.files && e.target.files[0]) {
            loadImageFromFile(e.target.files[0]);
        }
    });

    window.addEventListener('dragover', (e) => e.preventDefault());
    window.addEventListener('drop', (e) => {
        e.preventDefault();
        if (e.dataTransfer.files && e.dataTransfer.files[0]) {
            const file = e.dataTransfer.files[0];
            if (file.type.startsWith('image/')) {
                loadImageFromFile(file);
            }
        }
    });
}

function loadImageFromFile(file) {
    const reader = new FileReader();
    reader.onload = (e) => {
        const img = new Image();
        img.onload = () => {
            originalImage = img;
            dropzone.classList.remove('active');
            dropzone.classList.add('hidden');
            initCanvasForImage();
            render();
        };
        img.src = e.target.result;
    };
    reader.readAsDataURL(file);
}

function initCanvasForImage() {
    if (!originalImage) return;

    const maxW = previewContainer.clientWidth || 1200;
    const maxH = previewContainer.clientHeight || 800;
    const aspect = originalImage.naturalWidth / originalImage.naturalHeight;

    let w = maxW;
    let h = maxW / aspect;
    if (h > maxH) {
        h = maxH;
        w = maxH * aspect;
    }

    editorCanvas.width = Math.round(w);
    editorCanvas.height = Math.round(h);

    resizeSlidersBasedOnImage();
}

function resizeSlidersBasedOnImage() {
    if (!originalImage) return;
    const w = editorCanvas.width;
    const h = editorCanvas.height;

    const panXEl = document.getElementById('range-pan-x');
    const panYEl = document.getElementById('range-pan-y');

    if (panXEl) {
        panXEl.min = -Math.round(w);
        panXEl.max = Math.round(w);
    }
    if (panYEl) {
        panYEl.min = -Math.round(h);
        panYEl.max = Math.round(h);
    }
}

// Mouse Drag-to-Pan, DoF Focus, and Patch Retouching
function setupMouseInteraction() {
    editorCanvas.addEventListener('mousedown', (e) => {
        if (!originalImage) return;

        // Manual Patch Retouch Mode
        if (state.hudCleaner.patchMode) {
            isPatching = true;
            addPatchFromMouseEvent(e);
            return;
        }

        // DoF Focus Selection
        if (state.dof.type !== 'none') {
            const rect = editorCanvas.getBoundingClientRect();
            const clickX = (e.clientX - rect.left) / rect.width;
            const clickY = (e.clientY - rect.top) / rect.height;

            state.dof.focusX = clickX;
            state.dof.focusY = clickY;

            updateDofFocusMarker();
            render();
        }

        isPanning = true;
        startPanX = e.clientX - state.camera.panX;
        startPanY = e.clientY - state.camera.panY;
    });

    window.addEventListener('mousemove', (e) => {
        if (isPatching && state.hudCleaner.patchMode) {
            addPatchFromMouseEvent(e);
            return;
        }

        if (!isPanning) return;
        state.camera.panX = Math.round(e.clientX - startPanX);
        state.camera.panY = Math.round(e.clientY - startPanY);

        const panXEl = document.getElementById('range-pan-x');
        const panYEl = document.getElementById('range-pan-y');
        if (panXEl) { panXEl.value = state.camera.panX; document.getElementById('val-pan-x').textContent = state.camera.panX + 'px'; }
        if (panYEl) { panYEl.value = state.camera.panY; document.getElementById('val-pan-y').textContent = state.camera.panY + 'px'; }

        render();
    });

    window.addEventListener('mouseup', () => {
        isPanning = false;
        isPatching = false;
    });
}

function addPatchFromMouseEvent(e) {
    const rect = editorCanvas.getBoundingClientRect();
    const nx = (e.clientX - rect.left) / rect.width;
    const ny = (e.clientY - rect.top) / rect.height;
    if (nx < 0 || nx > 1 || ny < 0 || ny > 1) return;

    state.hudCleaner.patches.push({
        x: nx,
        y: ny,
        radius: state.hudCleaner.brushSize
    });
    render();
}

function updateDofFocusMarker() {
    if (state.dof.type === 'none') return;
    const rect = editorCanvas.getBoundingClientRect();
    const parentRect = previewContainer.getBoundingClientRect();

    const canvasLeft = rect.left - parentRect.left;
    const canvasTop = rect.top - parentRect.top;

    const posX = canvasLeft + state.dof.focusX * rect.width;
    const posY = canvasTop + state.dof.focusY * rect.height;

    dofFocusMarker.style.left = `${posX}px`;
    dofFocusMarker.style.top = `${posY}px`;
}

// Reset All Adjustments
function resetAllAdjustments() {
    state.adjustments = { exposure: 0, brightness: 0, contrast: 0, saturation: 0, temp: 0, vignette: 0, grain: 0, aberration: 0 };
    state.camera = { zoom: 1, tilt: 0, pitch: 0, yaw: 0, panX: 0, panY: 0, fisheye: 0 };
    state.gemini = { activePreset: 'quantv_ultra', enbBloom: 30, enbRaytrace: 40, wetRoads: 0, customPrompt: '', isGenerating: false };

    sliders.forEach(config => {
        const el = document.getElementById(config.id);
        if (!el) return;
        const def = el.getAttribute('value') || 0;
        el.value = def;
        const valEl = document.getElementById(config.valId);
        if (valEl) valEl.textContent = def + config.suffix;
    });

    render();
}

// Hard Reset Everything
function hardResetAll() {
    resetAllAdjustments();
    state.filters.active = 'natural';
    state.dof.type = 'none';
    textOverlayState.overlays = [];
    state.hudCleaner = {
        cleanMinimap: false,
        cleanStatus: false,
        cleanSpeedo: false,
        cleanCrosshair: false,
        cleanWatermarks: false,
        patchMode: false,
        brushSize: 25,
        patches: []
    };
    ['chk-clean-minimap', 'chk-clean-status', 'chk-clean-speedo', 'chk-clean-crosshair', 'chk-clean-watermarks'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.checked = false;
    });

    document.querySelectorAll('.filter-card').forEach(c => c.classList.remove('active'));
    const naturalCard = document.querySelector('.filter-card[data-filter="natural"]');
    if (naturalCard) naturalCard.classList.add('active');

    if (originalImage) render();

    const btn = document.getElementById('btn-reset-all');
    btn.innerHTML = '<span class="material-symbols-outlined text-[18px]">check</span> <span>Zresetowano!</span>';
    btn.style.backgroundColor = '#00E676';
    btn.style.color = '#0A0A0B';
    setTimeout(() => {
        btn.innerHTML = '<span class="material-symbols-outlined text-[18px]">restart_alt</span> <span>Reset Efektów</span>';
        btn.style.backgroundColor = '';
        btn.style.color = '';
    }, 1500);
}

// Load Demo Image (Night Los Santos Scene)
function loadDemoImage() {
    const demoCanvas = document.createElement('canvas');
    demoCanvas.width = 1920;
    demoCanvas.height = 1080;
    const dCtx = demoCanvas.getContext('2d');

    // Sky gradient
    const skyGrad = dCtx.createLinearGradient(0, 0, 0, 1080);
    skyGrad.addColorStop(0, '#050714');
    skyGrad.addColorStop(0.5, '#121b2d');
    skyGrad.addColorStop(1, '#2c1e38');
    dCtx.fillStyle = skyGrad;
    dCtx.fillRect(0, 0, 1920, 1080);

    // City Skyline & Lights
    dCtx.fillStyle = '#0a0d1a';
    for (let i = 0; i < 30; i++) {
        const bw = 60 + Math.random() * 90;
        const bh = 300 + Math.random() * 450;
        const bx = i * 65;
        dCtx.fillRect(bx, 1080 - bh, bw, bh);

        // Building windows
        dCtx.fillStyle = Math.random() > 0.4 ? '#46BEFF' : '#fcaf17';
        for (let wy = 1080 - bh + 20; wy < 1080 - 100; wy += 25) {
            for (let wx = bx + 10; wx < bx + bw - 15; wx += 18) {
                if (Math.random() > 0.5) dCtx.fillRect(wx, wy, 8, 12);
            }
        }
        dCtx.fillStyle = '#0a0d1a';
    }

    // Wet Asphalt Road
    const roadGrad = dCtx.createLinearGradient(0, 700, 0, 1080);
    roadGrad.addColorStop(0, '#11131c');
    roadGrad.addColorStop(1, '#050508');
    dCtx.fillStyle = roadGrad;
    dCtx.fillRect(0, 700, 1920, 380);

    // Road Wet Reflections (Raytracing simulation)
    dCtx.fillStyle = 'rgba(70, 190, 255, 0.25)';
    dCtx.fillRect(400, 720, 300, 360);
    dCtx.fillStyle = 'rgba(252, 175, 23, 0.2)';
    dCtx.fillRect(1100, 710, 400, 370);

    // Simulated FiveM HUD Elements (so user can test HUD cleaner!)
    // Minimap (Bottom-Left)
    dCtx.fillStyle = 'rgba(0,0,0,0.7)';
    dCtx.beginPath();
    dCtx.arc(120, 960, 80, 0, Math.PI * 2);
    dCtx.fill();
    dCtx.lineWidth = 4;
    dCtx.strokeStyle = '#46BEFF';
    dCtx.stroke();

    // Health/Armor Bars (Bottom-Left)
    dCtx.fillStyle = '#00E676';
    dCtx.fillRect(40, 1045, 75, 8);
    dCtx.fillStyle = '#46BEFF';
    dCtx.fillRect(125, 1045, 75, 8);

    // Speedometer (Bottom-Right)
    dCtx.font = 'bold 36px "Inter", sans-serif';
    dCtx.fillStyle = '#ffffff';
    dCtx.fillText('124 KM/H', 1650, 1020);
    dCtx.font = '14px "Inter", sans-serif';
    dCtx.fillStyle = 'rgba(255,255,255,0.6)';
    dCtx.fillText('VINEWOOD BOULEVARD', 1650, 1045);

    // Server Watermark (Top-Right)
    dCtx.font = 'bold 16px "Manrope", sans-serif';
    dCtx.fillStyle = '#46BEFF';
    dCtx.fillText('ROLEPLAY SERVER #1 | DISCORD.GG/FIVEM', 1480, 40);

    const img = new Image();
    img.onload = () => {
        originalImage = img;
        dropzone.classList.remove('active');
        dropzone.classList.add('hidden');
        initCanvasForImage();
        render();
    };
    img.src = demoCanvas.toDataURL('image/png');
}

// ============================================================
// MAIN RENDERING PIPELINE & QUANTV / ENB SHADERS
// ============================================================

function render() {
    if (!originalImage) return;
    renderPipeline(editorCanvas, originalImage, ctx);
    updateDofFocusMarker();
}

function renderPipeline(canvas, img, renderCtx, isExport = false) {
    const width = canvas.width;
    const height = canvas.height;
    const scaleFactor = isExport ? (img.naturalWidth / editorCanvas.width) : 1;

    renderCtx.clearRect(0, 0, width, height);
    renderCtx.save();

    // 1. Combine Timecycle Filter & Basic Adjustments
    let filterString = '';

    switch (state.filters.active) {
        case 'vinewood': filterString += 'sepia(0.4) contrast(1.12) saturate(1.35) brightness(1.05) hue-rotate(-8deg) '; break;
        case 'ls-noir': filterString += 'grayscale(1) contrast(1.55) brightness(0.8) '; break;
        case 'vespucci': filterString += 'saturate(1.85) contrast(1.1) brightness(1.06) hue-rotate(8deg) '; break;
        case 'east-coast': filterString += 'saturate(0.45) contrast(1.05) hue-rotate(15deg) brightness(0.95) '; break;
        case 'biker': filterString += 'contrast(1.3) saturate(0.6) sepia(0.25) hue-rotate(-15deg) brightness(0.85) '; break;
        case 'sandy-shores': filterString += 'sepia(0.55) hue-rotate(-25deg) contrast(1.25) saturate(1.4) brightness(0.88) '; break;
        case 'night-vision': filterString += 'grayscale(1) sepia(1) hue-rotate(85deg) saturate(7) brightness(1.2) contrast(1.3) '; break;
        case 'thermal': filterString += 'invert(1) hue-rotate(180deg) saturate(3.5) contrast(1.4) '; break;
        case 'cinematic-blue': filterString += 'saturate(0.9) contrast(1.08) hue-rotate(195deg) brightness(0.92) sepia(0.1) '; break;
        case 'golden-hour': filterString += 'sepia(0.6) saturate(2.2) contrast(1.15) brightness(1.1) hue-rotate(-18deg) '; break;
        case 'midnight': filterString += 'brightness(0.55) contrast(1.3) saturate(0.5) hue-rotate(220deg) sepia(0.2) '; break;
        case 'storm': filterString += 'saturate(0.3) contrast(1.2) brightness(0.75) hue-rotate(170deg) '; break;
        case 'interior': filterString += 'sepia(0.7) saturate(1.6) contrast(1.1) brightness(0.9) hue-rotate(-30deg) '; break;
        case 'drunk': filterString += 'saturate(2.5) contrast(1.2) hue-rotate(45deg) brightness(1.1) blur(0.4px) '; break;
    }

    const brightnessVal = 100 + state.adjustments.brightness;
    const contrastVal = 100 + state.adjustments.contrast;
    const saturationVal = 100 + state.adjustments.saturation;
    const exposureVal = 100 + state.adjustments.exposure;

    const finalBrightness = (brightnessVal / 100) * (exposureVal / 100) * 100;
    filterString += `brightness(${finalBrightness}%) contrast(${contrastVal}%) saturate(${saturationVal}%) `;
    renderCtx.filter = filterString.trim() || 'none';

    // 2. Render 3D Perspective Transformations
    draw3DImage(
        renderCtx,
        img,
        state.camera.pitch,
        state.camera.yaw,
        state.camera.tilt,
        state.camera.zoom,
        state.camera.panX * scaleFactor,
        state.camera.panY * scaleFactor,
        width,
        height
    );
    renderCtx.restore();

    // 3. Apply FiveM / GTA V Smart HUD Cleaner Inpainting
    applyHudCleanerInpainting(canvas, renderCtx);

    // 4. QuantV & ENB Graphics Mod Shader Emulation Layer
    applyQuantvEnbShaderLayer(canvas, renderCtx, scaleFactor);

    // 5. Depth of Field (Blur)
    const blurVal = state.dof.blur * scaleFactor;
    if (state.dof.type !== 'none' && blurVal > 0) {
        applyDepthOfField(canvas, renderCtx, blurVal);
    }

    // 6. Vignette
    if (state.adjustments.vignette > 0) {
        renderCtx.save();
        const grad = renderCtx.createRadialGradient(
            width / 2, height / 2, 0,
            width / 2, height / 2, Math.sqrt(width*width + height*height) / 2
        );
        const strength = state.adjustments.vignette / 100;
        grad.addColorStop(0, 'rgba(0,0,0,0)');
        grad.addColorStop(0.5, `rgba(0,0,0,${strength * 0.15})`);
        grad.addColorStop(1, `rgba(0,0,0,${strength * 0.85})`);

        renderCtx.fillStyle = grad;
        renderCtx.fillRect(0, 0, width, height);
        renderCtx.restore();
    }

    // 7. Film Grain
    if (state.adjustments.grain > 0) {
        renderCtx.save();
        renderCtx.globalAlpha = state.adjustments.grain / 100;
        const pattern = renderCtx.createPattern(noiseCanvas, 'repeat');
        renderCtx.fillStyle = pattern;
        renderCtx.translate(Math.random() * 256, Math.random() * 256);
        renderCtx.fillRect(0, 0, width, height);
        renderCtx.restore();
    }

    // 8. Rockstar Text Overlays
    drawTextOverlays(canvas, renderCtx, scaleFactor);
}

// 3D Perspective Slice Simulation (Yaw, Pitch, Roll)
function draw3DImage(renderCtx, img, pitch, yaw, tilt, zoom, panX, panY, w, h) {
    renderCtx.save();

    renderCtx.translate(w / 2 + panX, h / 2 + panY);
    renderCtx.rotate((tilt * Math.PI) / 180);
    renderCtx.scale(zoom, zoom);
    renderCtx.translate(-w / 2, -h / 2);

    const buf2 = document.createElement('canvas');
    buf2.width = w;
    buf2.height = h;
    const b2Ctx = buf2.getContext('2d');

    const yawRad = (yaw * Math.PI) / 180;
    if (Math.abs(yaw) > 0.1) {
        const slices = 128;
        const sliceWidth = w / slices;
        const fov = 1000;

        for (let i = 0; i < slices; i++) {
            const sx = (i * img.naturalWidth) / slices;
            const sw = img.naturalWidth / slices;
            const px = i * sliceWidth - w / 2;

            const rx = px * Math.cos(yawRad);
            const rz = px * Math.sin(yawRad);

            const scale = fov / (fov + rz);
            const dx = w / 2 + rx * scale;
            const dy = h / 2 - (h / 2) * scale;
            const dw = sliceWidth * scale;
            const dh = h * scale;

            b2Ctx.drawImage(img, sx, 0, sw, img.naturalHeight, dx - dw / 2, dy, dw + 0.5, dh);
        }
    } else {
        b2Ctx.drawImage(img, 0, 0, w, h);
    }

    const pitchRad = (pitch * Math.PI) / 180;
    if (Math.abs(pitch) > 0.1) {
        const slices = 128;
        const sliceHeight = h / slices;
        const fov = 1000;

        for (let i = 0; i < slices; i++) {
            const sy = i * sliceHeight;
            const sh = sliceHeight;
            const py = sy - h / 2;

            const ry = py * Math.cos(pitchRad);
            const rz = py * Math.sin(pitchRad);

            const scale = fov / (fov + rz);
            const dx = w / 2 - (w / 2) * scale;
            const dy = h / 2 + ry * scale;
            const dw = w * scale;
            const dh = sliceHeight * scale;

            renderCtx.drawImage(buf2, 0, sy, w, sh, dx, dy - dh / 2, dw, dh + 0.5);
        }
    } else {
        renderCtx.drawImage(buf2, 0, 0);
    }
    renderCtx.restore();
}

// QuantV & ENB Graphics Mod Shader Emulation Pipeline
function applyQuantvEnbShaderLayer(canvas, ctx, scaleFactor) {
    const W = canvas.width;
    const H = canvas.height;

    ctx.save();

    // A. ENB Solar Bloom & Atmospheric Haze (Soft global screen blend, no spot artifacts)
    if (state.gemini.enbBloom > 0) {
        const bloomStr = state.gemini.enbBloom / 100;
        ctx.globalCompositeOperation = 'screen';
        ctx.globalAlpha = bloomStr * 0.25;

        const bloomGrad = ctx.createLinearGradient(0, 0, 0, H);
        bloomGrad.addColorStop(0, 'rgba(255, 240, 220, 0.4)');
        bloomGrad.addColorStop(1, 'rgba(70, 190, 255, 0.15)');

        ctx.fillStyle = bloomGrad;
        ctx.fillRect(0, 0, W, H);
    }

    // B. Wet Road Raytraced Specular Reflections
    if (state.gemini.wetRoads > 0) {
        const wetStr = state.gemini.wetRoads / 100;
        ctx.globalCompositeOperation = 'overlay';
        ctx.globalAlpha = wetStr * 0.4;

        const wetGrad = ctx.createLinearGradient(0, H * 0.6, 0, H);
        wetGrad.addColorStop(0, 'rgba(255, 255, 255, 0)');
        wetGrad.addColorStop(0.5, 'rgba(70, 190, 255, 0.25)');
        wetGrad.addColorStop(1, 'rgba(255, 255, 255, 0.5)');

        ctx.fillStyle = wetGrad;
        ctx.fillRect(0, H * 0.6, W, H * 0.4);
    }

    // C. ENB Ambient Occlusion & Cinematic Tonemapping Contrast
    if (state.gemini.enbRaytrace > 0) {
        const rayStr = state.gemini.enbRaytrace / 100;
        ctx.globalCompositeOperation = 'soft-light';
        ctx.globalAlpha = rayStr * 0.35;

        const rayGrad = ctx.createLinearGradient(0, 0, W, H);
        rayGrad.addColorStop(0, 'rgba(255, 255, 255, 0.15)');
        rayGrad.addColorStop(1, 'rgba(0, 0, 0, 0.4)');

        ctx.fillStyle = rayGrad;
        ctx.fillRect(0, 0, W, H);
    }

    ctx.restore();
}

// Depth of Field (DoF) Blur Layering
function applyDepthOfField(canvas, renderCtx, blurVal) {
    const width = canvas.width;
    const height = canvas.height;

    const tmpCanvas = document.createElement('canvas');
    tmpCanvas.width = width;
    tmpCanvas.height = height;
    const tmpCtx = tmpCanvas.getContext('2d');

    tmpCtx.filter = `blur(${blurVal}px)`;
    tmpCtx.drawImage(canvas, 0, 0);

    const maskCanvas = document.createElement('canvas');
    maskCanvas.width = width;
    maskCanvas.height = height;
    const maskCtx = maskCanvas.getContext('2d');

    const focusX = state.dof.focusX * width;
    const focusY = state.dof.focusY * height;

    if (state.dof.type === 'radial') {
        const outerRadius = Math.max(width, height) * (state.dof.size / 100);
        const innerRadius = outerRadius * 0.3;

        const grad = maskCtx.createRadialGradient(focusX, focusY, innerRadius, focusX, focusY, outerRadius);
        grad.addColorStop(0, 'rgba(0,0,0,0)');
        grad.addColorStop(1, 'rgba(0,0,0,1)');

        maskCtx.fillStyle = grad;
        maskCtx.fillRect(0, 0, width, height);
    } else if (state.dof.type === 'linear') {
        maskCtx.save();
        maskCtx.translate(focusX, focusY);
        maskCtx.rotate((state.dof.angle * Math.PI) / 180);

        const bandHeight = height * (state.dof.size / 100);
        const grad = maskCtx.createLinearGradient(0, -height, 0, height);
        grad.addColorStop(0, 'rgba(0,0,0,1)');
        grad.addColorStop(0.5 - bandHeight / (height * 2), 'rgba(0,0,0,0)');
        grad.addColorStop(0.5 + bandHeight / (height * 2), 'rgba(0,0,0,0)');
        grad.addColorStop(1, 'rgba(0,0,0,1)');

        maskCtx.fillStyle = grad;
        maskCtx.fillRect(-width * 2, -height * 2, width * 4, height * 4);
        maskCtx.restore();
    }

    tmpCtx.globalCompositeOperation = 'destination-in';
    tmpCtx.drawImage(maskCanvas, 0, 0);

    renderCtx.drawImage(tmpCanvas, 0, 0);
}

// Rockstar Editor Text Overlays
function setupTextOverlay() {
    document.querySelectorAll('#text-style-group .btn-toggle').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('#text-style-group .btn-toggle').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            textOverlayState.textStyle = btn.dataset.textstyle;
        });
    });

    document.querySelectorAll('#text-position-group .btn-toggle').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('#text-position-group .btn-toggle').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            textOverlayState.pos = btn.dataset.pos;
        });
    });

    document.querySelectorAll('.color-swatch').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.color-swatch').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            textOverlayState.color = btn.dataset.color;
        });
    });

    document.getElementById('btn-add-text').addEventListener('click', () => {
        if (!originalImage) return;
        const text = document.getElementById('text-overlay-input').value.trim();
        if (!text) return;
        const sub = document.getElementById('text-overlay-sub').value.trim();
        textOverlayState.overlays.push({ text, sub, style: textOverlayState.textStyle, pos: textOverlayState.pos, color: textOverlayState.color });
        render();
    });

    document.getElementById('btn-clear-text').addEventListener('click', () => {
        textOverlayState.overlays = [];
        render();
    });
}

function drawTextOverlays(canvas, renderCtx, scaleFactor) {
    if (textOverlayState.overlays.length === 0) return;
    const W = canvas.width;
    const H = canvas.height;

    textOverlayState.overlays.forEach(ov => {
        const s = ov.style;
        const pos = ov.pos;
        const col = ov.color;

        const marginX = Math.round(W * 0.04);
        const marginY = Math.round(H * 0.06);

        let x, y, textAlign;
        if (pos === 'bottom-left') { x = marginX; y = H - marginY; textAlign = 'left'; }
        if (pos === 'bottom-center') { x = W / 2; y = H - marginY; textAlign = 'center'; }
        if (pos === 'top-left') { x = marginX; y = marginY + 30; textAlign = 'left'; }
        if (pos === 'top-center') { x = W / 2; y = marginY + 30; textAlign = 'center'; }

        renderCtx.save();
        renderCtx.textAlign = textAlign;

        if (s === 'location') {
            const lineW = Math.min(W * 0.35, 500) * scaleFactor;
            const lineH = Math.max(2, 2 * scaleFactor);
            let lineX = (pos.includes('center')) ? x - lineW / 2 : x;

            renderCtx.fillStyle = col;
            renderCtx.fillRect(lineX, y - Math.round(60 * scaleFactor), lineW, lineH);

            const barH = Math.round(80 * scaleFactor);
            const barY = y - Math.round(55 * scaleFactor);
            renderCtx.fillStyle = 'rgba(0,0,0,0.45)';
            const barW = Math.min(W * 0.55, 750) * scaleFactor;
            const barX = (pos.includes('center')) ? x - barW / 2 : x - Math.round(8 * scaleFactor);
            renderCtx.fillRect(barX, barY, barW, barH);

            const mainSize = Math.round(28 * scaleFactor);
            renderCtx.font = `700 ${mainSize}px 'Inter', 'Arial', sans-serif`;
            renderCtx.letterSpacing = `${2 * scaleFactor}px`;
            renderCtx.fillStyle = col;
            renderCtx.shadowColor = 'rgba(0,0,0,0.9)';
            renderCtx.shadowBlur = 8 * scaleFactor;
            renderCtx.fillText(ov.text.toUpperCase(), x, y - Math.round(28 * scaleFactor));

            if (ov.sub) {
                const subSize = Math.round(14 * scaleFactor);
                renderCtx.font = `300 ${subSize}px 'Inter', 'Arial', sans-serif`;
                renderCtx.letterSpacing = `${4 * scaleFactor}px`;
                renderCtx.fillStyle = 'rgba(255,255,255,0.7)';
                renderCtx.shadowBlur = 4 * scaleFactor;
                renderCtx.fillText(ov.sub.toUpperCase(), x, y - Math.round(8 * scaleFactor));
            }
        } else if (s === 'subtitle') {
            const mainSize = Math.round(22 * scaleFactor);
            renderCtx.font = `400 ${mainSize}px 'Inter', sans-serif`;
            renderCtx.shadowColor = '#000';
            renderCtx.shadowBlur = 10 * scaleFactor;
            renderCtx.strokeStyle = 'rgba(0,0,0,0.9)';
            renderCtx.lineWidth = 4 * scaleFactor;
            renderCtx.strokeText(ov.text, x, y);
            renderCtx.fillStyle = col;
            renderCtx.fillText(ov.text, x, y);
        } else if (s === 'title') {
            const mainSize = Math.round(48 * scaleFactor);
            renderCtx.font = `800 ${mainSize}px 'Inter', sans-serif`;
            renderCtx.shadowColor = 'rgba(0,0,0,0.95)';
            renderCtx.shadowBlur = 20 * scaleFactor;
            renderCtx.fillStyle = col;
            renderCtx.fillText(ov.text, x, y);
        }

        renderCtx.restore();
    });
}

// Export Functions
function downloadImage() {
    if (!originalImage) return;

    const exportCanvas = document.createElement('canvas');
    exportCanvas.width = originalImage.naturalWidth;
    exportCanvas.height = originalImage.naturalHeight;
    const exportCtx = exportCanvas.getContext('2d');

    renderPipeline(exportCanvas, originalImage, exportCtx, true);

    const format = state.export.format;
    const quality = state.export.quality / 100;
    const mimeType = format === 'jpg' ? 'image/jpeg' : 'image/png';

    const dataUrl = exportCanvas.toDataURL(mimeType, quality);
    const link = document.createElement('a');
    link.download = `fivem_gemini_quantv_${Date.now()}.${format}`;
    link.href = dataUrl;
    link.click();
}

function copyToClipboard() {
    if (!originalImage) return;

    const exportCanvas = document.createElement('canvas');
    exportCanvas.width = originalImage.naturalWidth;
    exportCanvas.height = originalImage.naturalHeight;
    const exportCtx = exportCanvas.getContext('2d');

    renderPipeline(exportCanvas, originalImage, exportCtx, true);

    exportCanvas.toBlob((blob) => {
        try {
            const item = new ClipboardItem({ 'image/png': blob });
            navigator.clipboard.write([item]).then(() => {
                const btn = btnCopyClipboard;
                const oldHTML = btn.innerHTML;
                btn.innerHTML = '<span class="material-symbols-outlined text-[20px]">check</span> <span>Skopiowano do schowka!</span>';
                btn.style.backgroundColor = '#00E676';
                btn.style.color = '#0A0A0B';
                setTimeout(() => {
                    btn.innerHTML = oldHTML;
                    btn.style.backgroundColor = '';
                    btn.style.color = '';
                }, 2000);
            });
        } catch (err) {
            console.error('Clipboard copy failed: ', err);
        }
    }, 'image/png');
}

// ============================================================
// DISCORD OAUTH2 & BOT ROLE VERIFICATION ENGINE
// ============================================================

function initDiscordAuth() {
    const btnLogin = document.getElementById('btn-discord-login');
    const btnVerifyUser = document.getElementById('btn-verify-userid');
    const inputUserId = document.getElementById('discord-userid-input');
    const btnLogout = document.getElementById('btn-discord-logout');
    const statusBanner = document.getElementById('discord-auth-status');

    if (btnLogin) {
        btnLogin.addEventListener('click', () => {
            if (statusBanner) statusBanner.textContent = 'Łączenie z serwerem Discord OAuth2...';
            fetch('/api/discord-auth-url')
                .then(r => r.json())
                .then(data => {
                    if (data.url) {
                        window.location.href = data.url;
                    }
                })
                .catch(err => {
                    if (statusBanner) statusBanner.textContent = 'Błąd połączenia z serwerem Discord API!';
                });
        });
    }

    if (btnVerifyUser) {
        btnVerifyUser.addEventListener('click', () => {
            const userId = inputUserId ? inputUserId.value.trim() : '';
            if (!userId) {
                if (statusBanner) statusBanner.textContent = 'Proszę wpisać prawidłowy Discord User ID!';
                return;
            }
            verifyDiscordUserId(userId);
        });
    }

    if (btnLogout) {
        btnLogout.addEventListener('click', () => {
            localStorage.removeItem('discord_user_session');
            showDiscordLockScreen('Wylogowano pomyślnie. Zaloguj się ponownie.');
        });
    }

    // Check URL Hash for Implicit OAuth Token
    const hash = window.location.hash;
    if (hash && hash.includes('access_token=')) {
        const tokenMatch = hash.match(/access_token=([^&]+)/);
        if (tokenMatch && tokenMatch[1]) {
            const accessToken = tokenMatch[1];
            if (statusBanner) statusBanner.textContent = 'Pobieranie profilu użytkownika z Discord API...';

            fetch('https://discord.com/api/v10/users/@me', {
                headers: { 'Authorization': `Bearer ${accessToken}` }
            })
            .then(r => r.json())
            .then(userData => {
                window.history.replaceState({}, document.title, window.location.pathname);
                if (userData && userData.id) {
                    const avatarUrl = userData.avatar ? `https://cdn.discordapp.com/avatars/${userData.id}/${userData.avatar}.png` : 'logo.png';
                    verifyDiscordUserId(userData.id, false, userData.username, avatarUrl);
                } else {
                    showDiscordLockScreen('Nie udało się pobrać danych z konta Discord.');
                }
            })
            .catch(err => {
                window.history.replaceState({}, document.title, window.location.pathname);
                showDiscordLockScreen('Błąd autoryzacji tokenu Discord.');
            });
            return;
        }
    }

    // Check URL parameters from OAuth Callback
    const urlParams = new URLSearchParams(window.location.search);
    const authStatus = urlParams.get('auth');

    if (authStatus === 'success') {
        const id = urlParams.get('id');
        const user = urlParams.get('user');
        const avatar = urlParams.get('avatar');

        const sessionData = {
            userId: id,
            username: user || 'Discord User',
            avatar: avatar || 'logo.png',
            timestamp: Date.now()
        };

        localStorage.setItem('discord_user_session', JSON.stringify(sessionData));
        window.history.replaceState({}, document.title, window.location.pathname);

        unlockAppWithDiscordUser(sessionData);
        return;
    }

    if (authStatus === 'denied') {
        const reason = urlParams.get('reason');
        window.history.replaceState({}, document.title, window.location.pathname);
        showDiscordLockScreen(getDiscordErrorText(reason));
        return;
    }

    // Check stored session
    const savedSession = localStorage.getItem('discord_user_session');
    if (savedSession) {
        try {
            const session = JSON.parse(savedSession);
            if (session && session.userId) {
                verifyDiscordUserId(session.userId, true);
                return;
            }
        } catch (e) {
            localStorage.removeItem('discord_user_session');
        }
    }

    showDiscordLockScreen('Status: Oczekiwanie na autoryzację...');
}

function verifyDiscordUserId(userId, isSilent = false, overrideName = null, overrideAvatar = null) {
    const statusBanner = document.getElementById('discord-auth-status');
    if (!isSilent && statusBanner) {
        statusBanner.textContent = 'Sprawdzanie uprawnień konta...';
    }

    if (userId === '498540152243748864') {
        const sessionData = {
            userId: '498540152243748864',
            username: overrideName || 'Suslowatyy (Admin)',
            avatar: overrideAvatar || 'logo.png',
            is_admin: true,
            timestamp: Date.now()
        };
        localStorage.setItem('discord_user_session', JSON.stringify(sessionData));
        unlockAppWithDiscordUser(sessionData);
        return;
    }

    fetch(`/api/check-discord-user?user_id=${encodeURIComponent(userId)}`)
        .then(r => r.json())
        .then(data => {
            if (data.authorized) {
                const sessionData = {
                    userId: data.user_id,
                    username: overrideName || decodeURIComponent(data.username || 'Discord User'),
                    avatar: overrideAvatar || decodeURIComponent(data.avatar || 'logo.png'),
                    is_admin: data.is_admin || false,
                    timestamp: Date.now()
                };
                localStorage.setItem('discord_user_session', JSON.stringify(sessionData));
                unlockAppWithDiscordUser(sessionData);
            } else {
                localStorage.removeItem('discord_user_session');
                showDiscordLockScreen(getDiscordErrorText(data.status || 'NO_ROLE'));
            }
        })
        .catch(err => {
            if (!isSilent && statusBanner) {
                statusBanner.textContent = 'Błąd połączenia z lokalnym serwerem autoryzacji!';
            }
        });
}

let currentDiscordSession = null;
let heartbeatInterval = null;

function unlockAppWithDiscordUser(session) {
    currentDiscordSession = session;
    const overlay = document.getElementById('discord-auth-overlay');
    const profile = document.getElementById('discord-user-profile');
    const avatarImg = document.getElementById('discord-user-avatar');
    const userNameTxt = document.getElementById('discord-user-name');
    const btnAdminPanel = document.getElementById('btn-open-admin-panel');

    if (overlay) overlay.classList.add('hidden');
    if (profile) profile.classList.remove('hidden');

    if (userNameTxt) userNameTxt.textContent = session.username;
    if (avatarImg) {
        avatarImg.src = session.avatar && session.avatar.startsWith('http') ? session.avatar : 'logo.png';
    }

    // Show Admin Panel button for designated Admin ID
    const ADMIN_ID = '498540152243748864';
    const isAdmin = session.userId === ADMIN_ID || session.is_admin === true;

    if (btnAdminPanel) {
        if (isAdmin) {
            btnAdminPanel.classList.remove('hidden');
        } else {
            btnAdminPanel.classList.add('hidden');
        }
    }

    // Start periodic heartbeat
    startHeartbeat(session);
}

function startHeartbeat(session) {
    if (heartbeatInterval) clearInterval(heartbeatInterval);

    const sendBeat = () => {
        fetch('/api/heartbeat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                userId: session.userId,
                username: session.username,
                avatar: session.avatar,
                lastSeen: new Date().toLocaleTimeString('pl-PL')
            })
        }).catch(() => {});
    };

    sendBeat();
    heartbeatInterval = setInterval(sendBeat, 10000);
}

// ============================================================
// ADMIN PANEL & USER ACCESS CONTROL CONTROLLER
// ============================================================

function setupAdminPanel() {
    const btnOpen = document.getElementById('btn-open-admin-panel');
    const btnClose = document.getElementById('btn-close-admin-panel');
    const modal = document.getElementById('admin-panel-modal');
    const btnRefresh = document.getElementById('btn-refresh-active-users');
    const btnBlockManual = document.getElementById('btn-admin-block-user');
    const inputBlockId = document.getElementById('admin-block-userid-input');

    if (btnOpen && modal) {
        btnOpen.addEventListener('click', () => {
            modal.classList.remove('hidden');
            loadActiveUsers();
            loadBlockedUsers();
        });
    }

    if (btnClose && modal) {
        btnClose.addEventListener('click', () => {
            modal.classList.add('hidden');
        });
    }

    if (btnRefresh) {
        btnRefresh.addEventListener('click', () => {
            loadActiveUsers();
            loadBlockedUsers();
        });
    }

    if (btnBlockManual && inputBlockId) {
        btnBlockManual.addEventListener('click', () => {
            const userId = inputBlockId.value.trim();
            if (!userId) return;
            blockUserAccess(userId);
            inputBlockId.value = '';
        });
    }
}

function loadActiveUsers() {
    const listContainer = document.getElementById('active-users-list');
    if (!listContainer) return;

    fetch('/api/active-users')
        .then(r => r.json())
        .then(users => {
            if (!users || users.length === 0) {
                listContainer.innerHTML = '<div class="text-xs text-tactical-muted text-center py-4">Brak aktywnych użytkowników online</div>';
                return;
            }

            listContainer.innerHTML = users.map(u => {
                const avatar = u.avatar && u.avatar.startsWith('http') ? u.avatar : 'logo.png';
                return `
                    <div class="flex items-center justify-between bg-tactical-input/60 border border-white/5 rounded-tactical-sm p-2.5 text-xs">
                        <div class="flex items-center gap-2.5">
                            <img src="${avatar}" class="w-7 h-7 rounded-full object-cover border border-primary/40">
                            <div class="flex flex-col text-left">
                                <span class="font-manrope font-extrabold text-white uppercase">${u.username || 'User'}</span>
                                <span class="font-mono text-[10px] text-tactical-muted">ID: ${u.userId || u.username} • ${u.lastSeen || 'teraz'}</span>
                            </div>
                        </div>
                        <button onclick="blockUserAccess('${u.userId}')" class="btn-tactical bg-status-error/15 hover:bg-status-error/30 text-status-error border border-status-error/30 px-3 py-1 rounded-full text-[11px] font-manrope font-extrabold uppercase tracking-wider flex items-center gap-1">
                            <span class="material-symbols-outlined text-[14px]">block</span>
                            <span>Zabierz Dostęp</span>
                        </button>
                    </div>
                `;
            }).join('');
        })
        .catch(() => {
            listContainer.innerHTML = '<div class="text-xs text-status-error text-center py-2">Błąd wczytywania aktywnych użytkowników</div>';
        });
}

function loadBlockedUsers() {
    const listContainer = document.getElementById('blocked-users-list');
    if (!listContainer) return;

    fetch('/api/blocked-users')
        .then(r => r.json())
        .then(blockedIds => {
            if (!blockedIds || blockedIds.length === 0) {
                listContainer.innerHTML = '<div class="text-xs text-tactical-muted text-center py-2">Brak zablokowanych użytkowników</div>';
                return;
            }

            listContainer.innerHTML = blockedIds.map(id => `
                <div class="flex items-center justify-between bg-tactical-input/60 border border-status-error/20 rounded-tactical-sm p-2 text-xs">
                    <span class="font-mono text-status-error font-bold">User ID: ${id}</span>
                    <button onclick="unblockUserAccess('${id}')" class="btn-tactical bg-status-success/15 hover:bg-status-success/30 text-status-success border border-status-success/30 px-3 py-0.5 rounded-full text-[11px] font-manrope font-extrabold uppercase tracking-wider flex items-center gap-1">
                        <span class="material-symbols-outlined text-[14px]">check_circle</span>
                        <span>Przywróć Dostęp</span>
                    </button>
                </div>
            `).join('');
        })
        .catch(() => {});
}

function blockUserAccess(userId) {
    fetch(`/api/block-user?user_id=${encodeURIComponent(userId)}`)
        .then(r => r.json())
        .then(() => {
            loadActiveUsers();
            loadBlockedUsers();
        });
}

function unblockUserAccess(userId) {
    fetch(`/api/unblock-user?user_id=${encodeURIComponent(userId)}`)
        .then(r => r.json())
        .then(() => {
            loadActiveUsers();
            loadBlockedUsers();
        });
}

// ============================================================
// VERSION INFORMATION & MODAL CONTROLLER
// ============================================================

function setupPatcherUpdater() {
    const modal = document.getElementById('update-modal');
    const btnClose = document.getElementById('btn-close-update-modal');

    if (btnClose && modal) {
        btnClose.addEventListener('click', () => {
            modal.classList.add('hidden');
        });
    }
}

function showDiscordLockScreen(msg) {
    const overlay = document.getElementById('discord-auth-overlay');
    const profile = document.getElementById('discord-user-profile');
    const statusBanner = document.getElementById('discord-auth-status');

    if (overlay) overlay.classList.remove('hidden');
    if (profile) profile.classList.add('hidden');

    if (statusBanner) {
        statusBanner.textContent = msg;
        if (msg.includes('BRAK UPRAWNIEŃ') || msg.includes('Błąd') || msg.includes('nie posiada') || msg.includes('DOSTĘP ZABRONIONY') || msg.includes('zablokowany')) {
            statusBanner.className = 'w-full text-xs font-manrope font-bold py-2 px-3 rounded-tactical-sm bg-status-error/15 border border-status-error/40 text-status-error transition-all';
        } else if (msg.includes('SUKCES') || msg.includes('Witaj')) {
            statusBanner.className = 'w-full text-xs font-manrope font-bold py-2 px-3 rounded-tactical-sm bg-status-success/15 border border-status-success/40 text-status-success transition-all';
        } else {
            statusBanner.className = 'w-full text-xs font-manrope font-bold py-2 px-3 rounded-tactical-sm bg-primary/10 border border-primary/30 text-primary transition-all';
        }
    }
}

function getDiscordErrorText(reason) {
    if (reason === 'BLOCKED_BY_ADMIN') {
        return 'DOSTĘP ZABRONIONY! Twoje konto zostało zablokowane przez Administratora (Dostęp Zabrany).';
    }
    if (reason === 'NO_ROLE') {
        return 'BRAK UPRAWNIEŃ! Twoje konto Discord nie posiada wymaganej rangi (Role ID: 1535960899653730314).';
    }
    if (reason === 'NOT_IN_GUILD') {
        return 'DOSTĘP ZABRONIONY! Nie jesteś członkiem serwera Discord (Server ID: 1535228978208440340).';
    }
    return `Brak autoryzacji: ${reason || 'Odmowa dostępu'}`;
}

// Launch the application
window.onload = init;
