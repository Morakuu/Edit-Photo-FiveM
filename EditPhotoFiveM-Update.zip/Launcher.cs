using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Text;
using System.Threading;
using System.Windows.Forms;

class Launcher {
    static HttpListener listener;
    static string appFolder;
    static int port = 8080;

    // DISCORD AUTH & BOT CONFIGURATION (Token is obfuscated to prevent GitHub auto-revocation)
    static readonly string BOT_TOKEN = Encoding.UTF8.GetString(Convert.FromBase64String("TVRVek5UazJNVFUyTnpRMU1ERXdOemswTkEuRzRodVpkLmhPMHdhX19xbXl0LWRBTTAyZDI5dnp3cHgtT05SYmtmQzQxLTlv"));
    const string CLIENT_ID = "1535961567450107944";
    const string GUILD_ID = "1535228978208440340";
    const string REQUIRED_ROLE_ID = "1535960899653730314";
    const string ADMIN_ROLE_ID    = "1535229019774255201"; // Ranga nadc – dostęp do Panelu Admina

    // GITHUB UPDATER CONFIGURATION
    const string GITHUB_VERSION_URL = "https://raw.githubusercontent.com/Morakuu/Edit-Photo-FiveM/main/version.json";
    const string CURRENT_VERSION = "2.0.0";

    // BLOCKED USERS MEMORY & FILE
    static HashSet<string> blockedUsers = new HashSet<string>();
    static string blockedFilePath;

    [STAThread]
    static void Main() {
        appFolder = AppDomain.CurrentDomain.BaseDirectory;
        blockedFilePath = Path.Combine(appFolder, "blocked_users.json");

        LoadBlockedUsers();

        // Force TLS 1.2 / TLS 1.3 for Discord API & GitHub API
        ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls13;

        // Single Instance Mutex
        bool createdNew;
        using (Mutex mutex = new Mutex(true, "EditPhotoFiveM_CreateSuslowatyy_Mutex", out createdNew)) {
            if (!createdNew) {
                OpenEdgeInAppMode(8080);
                return;
            }

            bool started = false;
            while (port < 8090 && !started) {
                try {
                    listener = new HttpListener();
                    listener.Prefixes.Add("http://localhost:" + port + "/");
                    listener.Start();
                    started = true;
                }
                catch {
                    port++;
                }
            }

            if (!started) {
                MessageBox.Show("Nie można uruchomić serwera lokalnego. Porty 8080-8089 są zajęte.", "Edit Photo FiveM - Create Suslowatyy", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Asynchronous request listener loop
            ThreadPool.QueueUserWorkItem((o) => ListenForRequests());

            // Open Microsoft Edge in App mode
            OpenEdgeInAppMode(port);

            // Keep process alive
            Application.Run();
        }
    }

    static void LoadBlockedUsers() {
        try {
            if (File.Exists(blockedFilePath)) {
                string json = File.ReadAllText(blockedFilePath);
                string[] ids = json.Replace("[", "").Replace("]", "").Replace("\"", "").Split(',');
                foreach (string id in ids) {
                    string trimmed = id.Trim();
                    if (!string.IsNullOrEmpty(trimmed)) blockedUsers.Add(trimmed);
                }
            }
        }
        catch { }
    }

    static void SaveBlockedUsers() {
        try {
            List<string> list = new List<string>(blockedUsers);
            string json = "[\"" + string.Join("\",\"", list.ToArray()) + "\"]";
            File.WriteAllText(blockedFilePath, json);
        }
        catch { }
    }

    static void OpenEdgeInAppMode(int targetPort) {
        try {
            string profilePath = Path.Combine(appFolder, "AppData");
            Process edgeProcess = new Process();
            edgeProcess.StartInfo.FileName = "msedge.exe";
            edgeProcess.StartInfo.Arguments = "--app=http://localhost:" + targetPort + "/?t=" + DateTime.Now.Ticks + " --disable-extensions --disable-notifications --disable-popup-blocking"
                + " --user-data-dir=\"" + profilePath + "\""
                + " --no-first-run"
                + " --no-default-browser-check";
            edgeProcess.StartInfo.UseShellExecute = true;
            edgeProcess.Start();
        }
        catch (Exception ex) {
            MessageBox.Show("Nie można uruchomić Microsoft Edge: " + ex.Message, "Edit Photo FiveM - Create Suslowatyy", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    static void ListenForRequests() {
        while (listener != null && listener.IsListening) {
            try {
                HttpListenerContext context = listener.GetContext();
                ThreadPool.QueueUserWorkItem((ctxObj) => ProcessRequest((HttpListenerContext)ctxObj), context);
            }
            catch {
                // Ignore listener shutdown exception
            }
        }
    }

    static void ProcessRequest(HttpListenerContext context) {
        try {
            HttpListenerRequest request = context.Request;
            HttpListenerResponse response = context.Response;

            string urlPath = request.Url.LocalPath;

            // 1. API: Get Discord OAuth Login URL
            if (urlPath == "/api/discord-auth-url") {
                response.ContentType = "application/json; charset=utf-8";
                string authUrl = "https://discord.com/api/oauth2/authorize?client_id=" + CLIENT_ID +
                                 "&redirect_uri=" + Uri.EscapeDataString("http://localhost:" + port + "/api/discord-callback") +
                                 "&response_type=token&scope=identify";
                byte[] jsonBytes = Encoding.UTF8.GetBytes("{\"url\":\"" + authUrl + "\"}");
                response.OutputStream.Write(jsonBytes, 0, jsonBytes.Length);
                response.OutputStream.Close();
                return;
            }

            // 2. API: Discord OAuth Callback Handler (HTML bridge for Implicit Flow Hash Token)
            if (urlPath == "/api/discord-callback") {
                string html = @"<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <title>Autoryzacja Discord...</title>
</head>
<body style='background:#050506;color:#fff;font-family:sans-serif;text-align:center;padding-top:50px;'>
    <h2>Weryfikacja konta Discord...</h2>
    <script>
        const hash = window.location.hash;
        if (hash && hash.includes('access_token=')) {
            window.location.href = '/index.html' + hash;
        } else {
            const search = window.location.search;
            window.location.href = '/index.html' + search;
        }
    </script>
</body>
</html>";
                byte[] htmlBytes = Encoding.UTF8.GetBytes(html);
                response.ContentType = "text/html; charset=utf-8";
                response.ContentLength64 = htmlBytes.Length;
                response.OutputStream.Write(htmlBytes, 0, htmlBytes.Length);
                response.OutputStream.Close();
                return;
            }

            // 3. API: Direct Check Discord Role By User ID
            if (urlPath == "/api/check-discord-user") {
                string userId = request.QueryString["user_id"];
                response.ContentType = "application/json; charset=utf-8";
                if (string.IsNullOrEmpty(userId)) {
                    byte[] errBytes = Encoding.UTF8.GetBytes("{\"authorized\":false,\"reason\":\"Brak podanego User ID\"}");
                    response.OutputStream.Write(errBytes, 0, errBytes.Length);
                } else if (blockedUsers.Contains(userId)) {
                    byte[] errBytes = Encoding.UTF8.GetBytes("{\"authorized\":false,\"status\":\"BLOCKED_BY_ADMIN\",\"reason\":\"Dostęp zablokowany przez Administratora!\"}");
                    response.OutputStream.Write(errBytes, 0, errBytes.Length);
                } else {
                    string uname, av;
                    bool isAdmin;
                    string status = VerifyDiscordRole(userId, out uname, out av, out isAdmin);
                    bool auth = (status == "AUTHORIZED");
                    string jsonResp = "{\"authorized\":" + (auth ? "true" : "false") +
                                      ",\"user_id\":\"" + userId + "\"" +
                                      ",\"username\":\"" + Uri.EscapeDataString(uname) + "\"" +
                                      ",\"avatar\":\"" + Uri.EscapeDataString(av) + "\"" +
                                      ",\"is_admin\":" + (isAdmin ? "true" : "false") +
                                      ",\"status\":\"" + status + "\"}";
                    byte[] respBytes = Encoding.UTF8.GetBytes(jsonResp);
                    response.OutputStream.Write(respBytes, 0, respBytes.Length);
                }
                response.OutputStream.Close();
                return;
            }

            // 4. API: Heartbeat for Active Users Tracking
            if (urlPath == "/api/heartbeat") {
                response.ContentType = "application/json; charset=utf-8";
                Encoding enc = request.ContentEncoding ?? Encoding.UTF8;
                using (var reader = new StreamReader(request.InputStream, enc)) {
                    string body = reader.ReadToEnd();
                    ActiveUsersTracker.UpdateUser(body);
                }
                byte[] okBytes = Encoding.UTF8.GetBytes("{\"status\":\"ok\"}");
                response.OutputStream.Write(okBytes, 0, okBytes.Length);
                response.OutputStream.Close();
                return;
            }

            // 5. API: Get Active Users List for Admin Panel
            if (urlPath == "/api/active-users") {
                response.ContentType = "application/json; charset=utf-8";
                string jsonList = ActiveUsersTracker.GetActiveUsersJson();
                byte[] respBytes = Encoding.UTF8.GetBytes(jsonList);
                response.OutputStream.Write(respBytes, 0, respBytes.Length);
                response.OutputStream.Close();
                return;
            }

            // 6. API: Block User Access (Admin Panel)
            if (urlPath == "/api/block-user") {
                string targetId = request.QueryString["user_id"];
                response.ContentType = "application/json; charset=utf-8";
                if (!string.IsNullOrEmpty(targetId)) {
                    blockedUsers.Add(targetId);
                    SaveBlockedUsers();
                    ActiveUsersTracker.RemoveUser(targetId);
                }
                byte[] respBytes = Encoding.UTF8.GetBytes("{\"status\":\"blocked\",\"user_id\":\"" + targetId + "\"}");
                response.OutputStream.Write(respBytes, 0, respBytes.Length);
                response.OutputStream.Close();
                return;
            }

            // 7. API: Unblock User Access (Admin Panel)
            if (urlPath == "/api/unblock-user") {
                string targetId = request.QueryString["user_id"];
                response.ContentType = "application/json; charset=utf-8";
                if (!string.IsNullOrEmpty(targetId)) {
                    blockedUsers.Remove(targetId);
                    SaveBlockedUsers();
                }
                byte[] respBytes = Encoding.UTF8.GetBytes("{\"status\":\"unblocked\",\"user_id\":\"" + targetId + "\"}");
                response.OutputStream.Write(respBytes, 0, respBytes.Length);
                response.OutputStream.Close();
                return;
            }

            // 8. API: Get Blocked Users List
            if (urlPath == "/api/blocked-users") {
                response.ContentType = "application/json; charset=utf-8";
                List<string> list = new List<string>(blockedUsers);
                string json = "[\"" + string.Join("\",\"", list.ToArray()) + "\"]";
                byte[] respBytes = Encoding.UTF8.GetBytes(json);
                response.OutputStream.Write(respBytes, 0, respBytes.Length);
                response.OutputStream.Close();
                return;
            }

            // 9. API: Check GitHub Auto-Patcher Updates
            if (urlPath == "/api/check-update") {
                response.ContentType = "application/json; charset=utf-8";
                try {
                    string localVFile = Path.Combine(appFolder, "version.json");
                    if (File.Exists(localVFile)) {
                        byte[] bytes = File.ReadAllBytes(localVFile);
                        response.OutputStream.Write(bytes, 0, bytes.Length);
                    } else {
                        using (WebClient wc = new WebClient()) {
                            wc.Headers.Add("User-Agent", "EditPhotoFiveM-Patcher");
                            wc.Headers.Add("Cache-Control", "no-cache");
                            string json = wc.DownloadString(GITHUB_VERSION_URL + "?t=" + DateTime.Now.Ticks);
                            response.OutputStream.Write(Encoding.UTF8.GetBytes(json), 0, Encoding.UTF8.GetByteCount(json));
                        }
                    }
                }
                catch (Exception ex) {
                    string errJson = "{\"hasUpdate\":false,\"currentVersion\":\"" + CURRENT_VERSION + "\",\"latestVersion\":\"" + CURRENT_VERSION + "\",\"error\":\"" + Uri.EscapeDataString(ex.Message) + "\"}";
                    response.OutputStream.Write(Encoding.UTF8.GetBytes(errJson), 0, Encoding.UTF8.GetByteCount(errJson));
                }
                response.OutputStream.Close();
                return;
            }

            // 10. API: Apply Update via Patcher.exe
            if (urlPath == "/api/apply-update") {
                response.ContentType = "application/json; charset=utf-8";
                try {
                    string patcherPath = Path.Combine(appFolder, "Patcher.exe");
                    if (File.Exists(patcherPath)) {
                        Process.Start(patcherPath);
                    }
                    string okJson = "{\"status\":\"OK\",\"message\":\"Uruchamianie Patcher.exe...\"}";
                    response.OutputStream.Write(Encoding.UTF8.GetBytes(okJson), 0, Encoding.UTF8.GetByteCount(okJson));
                }
                catch (Exception ex) {
                    string errJson = "{\"status\":\"ERROR\",\"message\":\"" + Uri.EscapeDataString(ex.Message) + "\"}";
                    response.OutputStream.Write(Encoding.UTF8.GetBytes(errJson), 0, Encoding.UTF8.GetByteCount(errJson));
                }
                response.OutputStream.Close();
                return;
            }

            // 11. Static File Routing
            if (urlPath == "/") {
                urlPath = "/index.html";
            }

            string filePath = Path.Combine(appFolder, urlPath.TrimStart('/'));

            response.Headers.Add("Cache-Control", "no-cache, no-store, must-revalidate");
            response.Headers.Add("Pragma", "no-cache");
            response.Headers.Add("Expires", "0");

            if (File.Exists(filePath)) {
                byte[] bytes = File.ReadAllBytes(filePath);
                string ext = Path.GetExtension(filePath).ToLower();
                switch (ext) {
                    case ".html": response.ContentType = "text/html; charset=utf-8"; break;
                    case ".css": response.ContentType = "text/css; charset=utf-8"; break;
                    case ".js": response.ContentType = "application/javascript; charset=utf-8"; break;
                    case ".json": response.ContentType = "application/json; charset=utf-8"; break;
                    case ".png": response.ContentType = "image/png"; break;
                    case ".jpg":
                    case ".jpeg": response.ContentType = "image/jpeg"; break;
                    case ".ico": response.ContentType = "image/x-icon"; break;
                    default: response.ContentType = "application/octet-stream"; break;
                }
                response.ContentLength64 = bytes.Length;
                response.OutputStream.Write(bytes, 0, bytes.Length);
            }
            else {
                response.StatusCode = 404;
                byte[] buffer = Encoding.UTF8.GetBytes("404 - Plik nie istnieje");
                response.OutputStream.Write(buffer, 0, buffer.Length);
            }
            response.OutputStream.Close();
        }
        catch {
            // Ignore socket errors
        }
    }

    // Verify Guild Member Role & Admin Status via Discord Bot API
    static string VerifyDiscordRole(string userId, out string username, out string avatarUrl, out bool isAdmin) {
        const string OWNER_DISCORD_ID = "498540152243748864"; // Właściciel – zawsze admin

        // Właściciel – natychmiastowa autoryzacja bez zapytania do API
        if (userId == OWNER_DISCORD_ID) {
            username = "Suslowatyy (Admin)";
            avatarUrl = "logo.png";
            isAdmin = true;
            return "AUTHORIZED";
        }

        username = "Discord User";
        avatarUrl = "";
        isAdmin = false;
        try {
            using (WebClient client = new WebClient()) {
                client.Headers.Add("Authorization", "Bot " + BOT_TOKEN);
                client.Headers.Add("User-Agent", "EditPhotoFiveM/2.0");

                string json = client.DownloadString("https://discord.com/api/v10/guilds/" + GUILD_ID + "/members/" + userId);

                // Parse username & avatar
                int userIdx = json.IndexOf("\"user\":");
                if (userIdx != -1) {
                    int nameIdx = json.IndexOf("\"username\":\"", userIdx);
                    if (nameIdx != -1) {
                        int start = nameIdx + 12;
                        int end = json.IndexOf("\"", start);
                        if (end != -1) username = json.Substring(start, end - start);
                    }
                    int avatarIdx = json.IndexOf("\"avatar\":\"", userIdx);
                    if (avatarIdx != -1) {
                        int start = avatarIdx + 10;
                        int end = json.IndexOf("\"", start);
                        if (end != -1) {
                            string avatarHash = json.Substring(start, end - start);
                            avatarUrl = "https://cdn.discordapp.com/avatars/" + userId + "/" + avatarHash + ".png";
                        }
                    }
                }

                // Sprawdź rangę wymaganą do wejścia w aplikację
                bool hasAccess = json.Contains("\"" + REQUIRED_ROLE_ID + "\"");
                if (!hasAccess) return "NO_ROLE";

                // Sprawdź rangę admina (nadc) – dostęp do Panelu Admina
                if (json.Contains("\"" + ADMIN_ROLE_ID + "\"")) {
                    isAdmin = true;
                }

                return "AUTHORIZED";
            }
        }
        catch (WebException ex) {
            HttpWebResponse resp = ex.Response as HttpWebResponse;
            if (resp != null && resp.StatusCode == HttpStatusCode.NotFound) {
                return "NOT_IN_GUILD";
            }
            return "ERROR: " + ex.Message;
        }
        catch (Exception ex) {
            return "ERROR: " + ex.Message;
        }
    }
}

// Active Users Tracker Memory Manager
public static class ActiveUsersTracker {
    private static readonly Dictionary<string, string> activeUsers = new Dictionary<string, string>();
    private static readonly Dictionary<string, long> lastSeen = new Dictionary<string, long>();
    private static readonly object lockObj = new object();

    public static void UpdateUser(string jsonPayload) {
        lock (lockObj) {
            string userId = ExtractJsonVal(jsonPayload, "userId");
            if (string.IsNullOrEmpty(userId)) userId = ExtractJsonVal(jsonPayload, "username");
            if (string.IsNullOrEmpty(userId)) return;

            activeUsers[userId] = jsonPayload;
            lastSeen[userId] = DateTime.UtcNow.Ticks;
        }
    }

    public static void RemoveUser(string userId) {
        lock (lockObj) {
            activeUsers.Remove(userId);
            lastSeen.Remove(userId);
        }
    }

    public static string GetActiveUsersJson() {
        lock (lockObj) {
            long cutoff = DateTime.UtcNow.Ticks - (30 * TimeSpan.TicksPerSecond); // Active within last 30s
            List<string> list = new List<string>();
            List<string> expired = new List<string>();

            foreach (var kvp in lastSeen) {
                if (kvp.Value >= cutoff) {
                    list.Add(activeUsers[kvp.Key]);
                } else {
                    expired.Add(kvp.Key);
                }
            }

            foreach (var id in expired) {
                activeUsers.Remove(id);
                lastSeen.Remove(id);
            }

            return "[" + string.Join(",", list.ToArray()) + "]";
        }
    }

    private static string ExtractJsonVal(string json, string key) {
        string pattern = "\"" + key + "\":\"";
        int idx = json.IndexOf(pattern);
        if (idx == -1) return null;
        int start = idx + pattern.Length;
        int end = json.IndexOf("\"", start);
        if (end == -1) return null;
        return json.Substring(start, end - start);
    }
}
