# ============================================================
# EDIT PHOTO FIVEM - GITHUB AUTO-PUBLISH UPDATE SCRIPT
# Created by Suslowatyy
# ============================================================

param(
    [string]$Version = "2.0.1",
    [string]$Changelog = "Wydanie nowej wersji silnika Edit Photo FiveM.",
    [string]$GitHubToken = ""
)

$RepoOwner = "Morakuu"
$RepoName = "Edit-Photo-FiveM"
$ProjectDir = $PSScriptRoot

# Read token from local file if available
$TokenFile = Join-Path $ProjectDir "github_token.txt"
if ([string]::IsNullOrEmpty($GitHubToken) -and (Test-Path $TokenFile)) {
    $GitHubToken = (Get-Content $TokenFile -Raw).Trim()
}

Write-Host "============================================================" -ForegroundColor Cyan
Write-Host " EDIT PHOTO FIVEM - AUTOMATYCZNE WYDAWANIE PATCHA GITHUB" -ForegroundColor Yellow
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host " Nowa Wersja: v${Version}" -ForegroundColor Green
Write-Host " Repozytorium: https://github.com/${RepoOwner}/${RepoName}" -ForegroundColor Green
Write-Host "============================================================" -ForegroundColor Cyan

# 1. Update version.json
$VersionData = @{
    latestVersion = $Version
    hasUpdate = $true
    downloadUrl = "https://raw.githubusercontent.com/${RepoOwner}/${RepoName}/main/EditPhotoFiveM-Update.zip"
    changelog = "Wersja v${Version} - Edit Photo FiveM:`n${Changelog}"
} | ConvertTo-Json -Depth 3

$VersionFilePath = Join-Path $ProjectDir "version.json"
[System.IO.File]::WriteAllText($VersionFilePath, $VersionData, [System.Text.Encoding]::UTF8)
Write-Host "[*] Zaktualizowano lokalny plik version.json (v${Version})" -ForegroundColor Green

# 2. Package application files into EditPhotoFiveM-Update.zip
$ZipPath = Join-Path $ProjectDir "EditPhotoFiveM-Update.zip"
if (Test-Path $ZipPath) { Remove-Item $ZipPath -Force }

Write-Host "[i] Pakowanie plików aplikacji do EditPhotoFiveM-Update.zip..." -ForegroundColor Yellow

$ExcludeFiles = @(
    "EditPhotoFiveM-Update.zip",
    "EditPhotoFiveM-Payload.zip",
    "EditPhotoFiveM-Instalator.exe",
    "github_token.txt",
    "blocked_users.json",
    "AppData",
    "webview2",
    "webview2.zip",
    "Launcher_backup.cs",
    "WebViewTest.exe",
    "WebViewTest.cs",
    "StagingTemp",
    "*.log",
    "*.git*"
)

# Stwórz tymczasowy folder stagingowy
$StagingDir = Join-Path $ProjectDir "StagingTemp"
if (Test-Path $StagingDir) { Remove-Item $StagingDir -Recurse -Force }
New-Item -ItemType Directory -Path $StagingDir | Out-Null

# Kopiowanie plików do stagingu z zachowaniem struktury
Get-ChildItem -Path $ProjectDir | Where-Object { $ExcludeFiles -notcontains $_.Name } | ForEach-Object {
    if ($_.PSIsContainer) {
        Copy-Item -Path $_.FullName -Destination $StagingDir -Recurse -Force
    } else {
        Copy-Item -Path $_.FullName -Destination $StagingDir -Force
    }
}

if (Test-Path $StagingDir) {
    Compress-Archive -Path "$StagingDir\*" -DestinationPath $ZipPath -Force
    Write-Host "[*] Utworzono paczkę aktualizacyjną EditPhotoFiveM-Update.zip" -ForegroundColor Green
}

# 3. Rebuild single-file installer EditPhotoFiveM-Instalator.exe
$PayloadZip = Join-Path $ProjectDir "EditPhotoFiveM-Payload.zip"
if (Test-Path $PayloadZip) { Remove-Item $PayloadZip -Force }
if (Test-Path $StagingDir) {
    Compress-Archive -Path "$StagingDir\*" -DestinationPath $PayloadZip -Force
}

Remove-Item $StagingDir -Recurse -Force

$CscPath = "C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if (Test-Path $CscPath) {
    & $CscPath /target:winexe /r:System.IO.Compression.dll /r:System.IO.Compression.FileSystem.dll /win32icon:"$ProjectDir\app.ico" /resource:"$PayloadZip" /out:"$ProjectDir\EditPhotoFiveM-Instalator.exe.tmp" "$ProjectDir\Installer.cs" | Out-Null
    if (Test-Path "$ProjectDir\EditPhotoFiveM-Instalator.exe.tmp") {
        Move-Item "$ProjectDir\EditPhotoFiveM-Instalator.exe.tmp" "$ProjectDir\EditPhotoFiveM-Instalator.exe" -Force
    }
    Write-Host "[*] Przeprojektowano jednoplikowy instalator EditPhotoFiveM-Instalator.exe" -ForegroundColor Green
}

# 4. GitHub API Push / Upload (version.json + EditPhotoFiveM-Update.zip)
if (-not [string]::IsNullOrEmpty($GitHubToken)) {
    Write-Host "[i] Wysyłanie plików na serwery GitHub API..." -ForegroundColor Yellow
    $Headers = @{
        "Authorization" = "Bearer $GitHubToken"
        "User-Agent"    = "EditPhotoFiveM-Publisher"
        "Accept"        = "application/vnd.github.v3+json"
    }

    # A. Upload version.json
    try {
        $VerRawText = Get-Content $VersionFilePath -Raw
        $VersionContent = [System.Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($VerRawText)) -replace '\s',''
        $GetVersionUrl = "https://api.github.com/repos/${RepoOwner}/${RepoName}/contents/version.json"
        
        $ExistingSha = ""
        try {
            $ExistingFile = Invoke-RestMethod -Uri $GetVersionUrl -Headers $Headers -Method Get
            $ExistingSha = $ExistingFile.sha
        } catch { }

        $MsgText = "Release v${Version}"
        $Body = @{
            message = $MsgText
            content = $VersionContent
        }
        if (-not [string]::IsNullOrEmpty($ExistingSha)) { $Body["sha"] = $ExistingSha }

        $JsonBody = $Body | ConvertTo-Json -Compress
        $Response = Invoke-RestMethod -Uri $GetVersionUrl -Headers $Headers -Method Put -Body $JsonBody -ContentType "application/json; charset=utf-8"
        Write-Host "[*] Pomyślnie wysłano version.json na GitHub!" -ForegroundColor Green
    }
    catch {
        Write-Host "[!] Błąd wysyłania version.json: $_" -ForegroundColor Red
    }

    # B. Upload EditPhotoFiveM-Update.zip
    if (Test-Path $ZipPath) {
        try {
            Write-Host "[i] Wysyłanie paczki zip (EditPhotoFiveM-Update.zip) na GitHub..." -ForegroundColor Yellow
            $ZipBytes = [System.IO.File]::ReadAllBytes($ZipPath)
            $ZipBase64 = [System.Convert]::ToBase64String($ZipBytes)
            $ZipUrl = "https://api.github.com/repos/${RepoOwner}/${RepoName}/contents/EditPhotoFiveM-Update.zip"

            $ExistingZipSha = ""
            try {
                $ExistingZipFile = Invoke-RestMethod -Uri $ZipUrl -Headers $Headers -Method Get
                $ExistingZipSha = $ExistingZipFile.sha
            } catch { }

            $ZipBody = @{
                message = "Update zip binary package v${Version}"
                content = $ZipBase64
            }
            if (-not [string]::IsNullOrEmpty($ExistingZipSha)) { $ZipBody["sha"] = $ExistingZipSha }

            $ZipJsonBody = $ZipBody | ConvertTo-Json
            $ZipResponse = Invoke-RestMethod -Uri $ZipUrl -Headers $Headers -Method Put -Body $ZipJsonBody -ContentType "application/json"
            Write-Host "[*] Pomyślnie wysłano EditPhotoFiveM-Update.zip na GitHub!" -ForegroundColor Green
        }
        catch {
            Write-Host "[!] Błąd wysyłania paczki ZIP na GitHub API: $_" -ForegroundColor Red
        }
    }
} else {
    Write-Host "[!] Wskazówka: Zapisz swój nowy token w pliku github_token.txt w folderze aplikacji." -ForegroundColor Yellow
}

Write-Host "============================================================" -ForegroundColor Cyan
Write-Host " SUKCES! Wydanie v${Version} jest przygotowane dla Patcher.exe!" -ForegroundColor Green
Write-Host "============================================================" -ForegroundColor Cyan
